// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <Rmath.h>
#include <Rcpp.h>
using namespace Rcpp;
using namespace arma;

// andom generation for the Multinomial distribution
arma::dvec rmultinom_cpp(int size,  arma::dvec a) {
  // meaning of n, size, prob as in ?rmultinom
  // opposite of sample() - n=number of draws
  double pp;            
  int ii;
  Rcpp::NumericVector prob = NumericVector(a.begin(), a.end());
  int probsize = prob.size();
  // Return object
  arma::dvec draws(probsize);
  if (size < 0 || size == NA_INTEGER) throw std::range_error( "Invalid size");
  long double p_tot = 0.;
  p_tot = std::accumulate(prob.begin(), prob.end(), p_tot);
  if (fabs((double)(p_tot - 1.)) > 1e-7) {
    throw std::range_error("Probabilities don't sum to 1, please use FixProb");
  }
  
  // do as rbinom
  if (size == 0 ) {
    return draws;
  }
  //rmultinom(size, REAL(prob), k, &INTEGER(ans)[ik]);
  // for each slot
  for (ii = 0; ii < probsize-1; ii++) { /* (p_tot, n) are for "remaining binomial" */
    if (prob[ii]) {
      pp = prob[ii] / p_tot;
      // >= 1; > 1 happens because of rounding 
      draws(ii) = ((pp < 1.) ? (int) Rf_rbinom((double) size,  pp) : size);
      size -= draws(ii);
    } // else { ret[ii] = 0; }
    // all done
    if (size <= 0)  return draws;
    // i.e. p_tot = sum(prob[(k+1):K]) 
    p_tot -= prob[ii]; 
  }
  // the rest go here
  draws(probsize-1) = size;
  return draws;
}

// Generate event time using Weibull distribution
double weibull(double p, double p_half, double T){
  // shape and scale is solution of p = 1- S(T) , p_half = 1- S(T/2) (where T is total evaluation time.)
  // S(T) = exp(-(T/scale)^{shape})
  double output, shape, scale;
  shape = log(log(1-p)/log(1-p_half))/log(2);
  scale = exp(log(T)-log(-log(1-p))/shape);
  output = Rcpp::rweibull(1, shape, scale)(0);
  return(output);
}

// Generate event time using log-logistic distribution
double logistic(double p, double p_half, double T){
  // alpha and lambda is solution of p = 1- S(T) , p_half = 1- S(T/2)
  // S(T) = 1/(1+(T/scale)^{shape})
  double output, u, shape, scale;
  shape = log((1/(1-p)-1)/(1/(1-p_half)-1))/log(2);
  scale = T/(exp(log(1/(1-p)-1)/shape));
  // Using Inverse-CDF to generate number from log-logistic distribution
  // ICDF(u) = scale * (u/(1-u))^{1/shape}
  u = Rcpp::runif(1, 0, 1)(0);
  output = scale * pow(u/(1-u), 1/shape);
  return(output);
}
 



// [[Rcpp::export]]
arma::vec outcome_gen2_cpp(arma::dvec prob_half, double prob_tp, double prob_nc, const int indicator_se,
                       const int outcome_dist_tp, const int outcome_dist_nc, double total_eval_time){
  
  // InPut Variable //
  // prob_half (size 4 vector): Probability of outcome occurrence for (se/low, se/std, re/std, re/high)
  // prob_tp: probability of TP occurence
  // prob_nc: probability of NC occurence
  // indicator_se: if patient is SE, the value is 1, else 0.
  // outcome_dist_tp: the distribution of (TP occurrence) time; weibull distribution:1 / logistic distribution: 0
  // outcome_dist_nc: the distribution of (NC occurrence) time; weibull distribution:1 / logistic distribution: 0
  // total_eval_time: evaluation time
  
  double prob_half_tp, prob_half_nc, event_time = total_eval_time + 1, u;
  arma::vec prob(4, fill::zeros);
  int indicator_tp, indicator_nc, out;
  arma::vec temp(4, fill::zeros);
  arma::vec outcome(4, fill::zeros);
  
  //prob_half_tp: probability of TP occurrence in first half interval.
  //prob_half_nc: probability of NC occurrence in first half interval.
  if(indicator_se == 1){
    prob_half_tp = prob_half(0) * prob_tp;
    prob_half_nc = prob_half(1) * prob_nc;
  }else{
    prob_half_tp = prob_half(2) * prob_tp;
    prob_half_nc = prob_half(3) * prob_nc;   
  }
  

  // Step 1) Generate data when the "Both TP and NC event occur" 
  u = Rcpp::runif(1, 0, 1)(0);
  if( u < 0.05){
    // indicator_tp / indicator_nc: whether each event occur 
    indicator_tp = 1;
    indicator_nc = 1;
    // determine which event occur first (we can only observe that events occur first)
    u = Rcpp::runif(1, 0, 1)(0);
    if(u < 0.5){
      out = 1; // TP
    }else{
      out = 2; // NC
    }
    
  // Generate time to event for each event (TP, NC)
    while(event_time > total_eval_time){
      if(out == 1){
        if(outcome_dist_tp == 1) event_time = weibull(prob_tp, prob_half_tp, total_eval_time);
          else event_time = logistic(prob_tp, prob_half_tp, total_eval_time);
      }else if(out == 2){
        if(outcome_dist_nc == 1) event_time = weibull(prob_nc, prob_half_nc, total_eval_time);
          else event_time = logistic(prob_nc, prob_half_nc, total_eval_time); 
      }
    }
  }else{
    // Step 2) Generate data when the "TP and NC events do not occur simultaneously." 
    out = 5; // initial value
    // determine the event (0:censored, 1:only TP, 2: only NC, 3: both occur)
    while(out >= 3){
      prob(0) = 1 - prob_tp - prob_nc; // the probability of censoring
      prob(1) = prob_tp - 0.025; // the probability of occurrence tp/nc is lowered because of "both occur case"
      prob(2) = prob_nc - 0.025;
      prob(3) = 0.05; // both occur case
      
      temp = round(rmultinom_cpp(1, prob));
      Rcpp::NumericVector temp2 = wrap(temp); // wrap: Change rcpparmadillo to rcppvector (because output of rmultinom_cpp() is rcpparmadillo)
      out = Rcpp::which_max(temp2); // The input of which_max() is rcpp vector
    }

    // Generate time to event for each event (TP, NC)
    // repeat until "event_time < total_eval_time" because "event_time > total_eval_time" means censoring, but we have already considered it when generate "out" .
    while(event_time > total_eval_time){
      if(out == 1){
        // TP
        if(outcome_dist_tp == 1) event_time = weibull(prob_tp, prob_half_tp, total_eval_time);
        else event_time = logistic(prob_tp, prob_half_tp, total_eval_time);
        indicator_tp = 1;
        indicator_nc = 0;
      }else if(out == 2){
        // NC
        if(outcome_dist_nc == 1) event_time = weibull(prob_nc, prob_half_nc, total_eval_time);
        else event_time = logistic(prob_nc, prob_half_nc, total_eval_time);
        indicator_tp = 0;
        indicator_nc = 1;
      }else if(out == 0){
        // Censoring
        event_time = total_eval_time;
        indicator_tp = 0;
        indicator_nc = 0;
      }
    }
  }
  
  outcome(0) = event_time;
  outcome(1) = indicator_tp;
  outcome(2) = indicator_nc;
  outcome(3) = out;
  
  return(outcome);
}

