// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
# include "truncated_normal.cpp"
using namespace arma;


// [[Rcpp::export]]
Rcpp::List comp_llog_new(arma::vec time, arma::vec w, arma::vec a, arma::vec b, const int niter, const int nburn, const int nthin,
                         const int nprint, arma::vec option, arma::vec jump_lambda, arma::vec jump_lambda2,
                         const double jump_eta1, const double jump_eta2,
                         const double jump_gamma1, const double jump_gamma2,
                         const double pr_mean_lambda, const double pr_sd_lambda, 
                         const double pr_shape_eta, const double pr_scale_eta, 
                         const double pr_shape_gamma, const double pr_scale_gamma){
  
  int i, j, count, accept, iter, seed;
  double old_like_lambda, new_like_lambda, old_like_gamma, new_like_gamma, old_like_eta, new_like_eta, old_lp1, new_lp1,
  old_lp2, new_lp2 ;
  double num, den, ratio, un, accept_eta1, accept_eta2, accept_gamma1, accept_gamma2;
  
  double n = time.size();
  double p = 3;
  
  
  arma::dvec oldlambda1(p, fill::randu);
  arma::dvec oldlambda2(p, fill::randu);
  oldlambda1 = oldlambda1 * 0.4 - 0.2;
  oldlambda2 = oldlambda2 * 0.4 - 0.2;
  arma::dvec newlambda1 = oldlambda1;
  arma::dvec newlambda2 = oldlambda2;
  double old_eta1 = R::runif(0,1);
  double old_eta2 = R::runif(0,1);
  double new_eta1 = old_eta1;
  double new_eta2 = old_eta2;
  double old_gamma1 = R::runif(0,1);
  double old_gamma2 = R::runif(0,1);
  double new_gamma1 = old_gamma1;
  double new_gamma2 = old_gamma2;
  arma::dmat samp_lambda1((niter-nburn)/nthin, p, fill::zeros);
  arma::dmat samp_lambda2((niter-nburn)/nthin, p, fill::zeros);
  arma::dvec samp_eta1((niter-nburn)/nthin, fill::zeros);
  arma::dvec samp_eta2((niter-nburn)/nthin, fill::zeros);
  arma::dvec samp_gamma1((niter-nburn)/nthin, fill::zeros);
  arma::dvec samp_gamma2((niter-nburn)/nthin, fill::zeros);
  
  arma::dvec accept_lambda1(p, fill::zeros);
  arma::dvec accept_lambda2(p, fill::zeros);
  accept_eta1 = 0;
  accept_eta2 = 0;
  accept_gamma1 = 0;
  accept_gamma2 = 0;
  accept = count = 0;
  
  //Start MCMC 
  for(iter = 0; iter < niter; iter++){
    
    //update lambda1
    for(i = 0; i < p; i++){
      newlambda1(i) = R::rnorm( oldlambda1(i), jump_lambda(i));
      old_like_lambda = new_like_lambda = 0.0;
      
      //Calculate likelihood 
      for(j = 0; j < n; j++){
        
        new_lp1 = 0; old_lp1 = 0, old_lp2 = 0;
        
        new_lp1 = newlambda1(0) * a(j) * w(j) + (newlambda1(1) * a(j) + newlambda1(2) *  b(j)) * (1-  w(j));
        old_lp1 = oldlambda1(0) * a(j) * w(j) + (oldlambda1(1) * a(j) + oldlambda1(2) *  b(j)) * (1-  w(j));
        
        old_lp2 = oldlambda2(0) * a(j) * w(j) + (oldlambda2(1) * a(j) + oldlambda2(2) *  b(j)) * (1-  w(j));
        
        new_like_lambda -= std::exp(new_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
        old_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
        
        // option: (0:censored, 1:only TP, 2: only NC)
        if(option(j) == 1){ 
          new_like_lambda += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + new_lp1;
          old_like_lambda += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
        }else if(option(j) == 2){
          new_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
          old_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
        }
      }//end Calculate likelihood 
      
      num = new_like_lambda + R::dnorm4(newlambda1(i), pr_mean_lambda, pr_sd_lambda, 1);
      den = old_like_lambda + R::dnorm4(oldlambda1(i), pr_mean_lambda, pr_sd_lambda, 1);
      ratio = num - den;
      
      if(ratio > 0.0) accept = 1;
      else{
        un = R::runif(0,1);
        if(std::log(un) < ratio) accept = 1;
        else accept = 0;
      }
      
      if(accept == 1){
        oldlambda1(i) = newlambda1(i);
        accept_lambda1(i) += 1.0 / (niter * 1.0);
      }else newlambda1(i) = oldlambda1(i);
    }
    
    //update lambda2
    for(i = 0; i < p; i++){
      newlambda2(i) = R::rnorm( oldlambda2(i), jump_lambda2(i));
      old_like_lambda = new_like_lambda = 0.0;
      
      //Calculate likelihood
      for(j = 0; j < n; j++){
        
        new_lp2= 0; old_lp2 = 0;
        old_lp1 = 0;
        
        new_lp2 = newlambda2(0) * a(j) * w(j) + (newlambda2(1) * a(j) + newlambda2(2) *  b(j)) * (1-  w(j));
        old_lp2 = oldlambda2(0) * a(j) * w(j) + (oldlambda2(1) * a(j) + oldlambda2(2) *  b(j)) * (1-  w(j));
        
        old_lp1 = oldlambda1(0) * a(j) * w(j) + (oldlambda1(1) * a(j) + oldlambda1(2) *  b(j)) * (1-  w(j));
        
        
        new_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(new_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
        old_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
        
        // option: (0:censored, 1:only TP, 2: only NC)
        if(option(j) == 1){ 
          new_like_lambda += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
          old_like_lambda += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
        }else if(option(j) == 2){
          new_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + new_lp2;
          old_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
        }
      }//end Calculate likelihood
      
      num = new_like_lambda + R::dnorm4(newlambda2(i), pr_mean_lambda, pr_sd_lambda, 1);
      den = old_like_lambda + R::dnorm4(oldlambda2(i), pr_mean_lambda, pr_sd_lambda, 1);
      ratio = num - den;
      
      if(ratio > 0.0) accept = 1;
      else{
        un = R::runif(0,1);
        if(std::log(un) < ratio) accept = 1;
        else accept = 0;
      }
      
      if(accept == 1){
        oldlambda2(i) = newlambda2(i);
        accept_lambda2(i) += 1.0 / (niter * 1.0);
      }else newlambda2(i) = oldlambda2(i);
    }
    
    
    // update eta1
    new_eta1 = truncated_normal_a_sample(old_eta1, jump_eta1, 0, seed);
    
    old_like_eta = new_like_eta = 0.0;
    
    //Calculate likelihood
    for(j = 0; j < n; j++){
      
      old_lp2 = 0;
      old_lp1 = 0;
      
      old_lp1 = oldlambda1(0) * a(j) * w(j) + (oldlambda1(1) * a(j) + oldlambda1(2) *  b(j)) * (1-  w(j));
      old_lp2 = oldlambda2(0) * a(j) * w(j) + (oldlambda2(1) * a(j) + oldlambda2(2) *  b(j)) * (1-  w(j));
      
      new_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), new_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
      old_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
      
      // option: (0:censored, 1:only TP, 2: only NC)
      if(option(j) == 1){ 
        new_like_lambda += std::log(new_eta1) + new_eta1 * std::log(old_gamma1) + (new_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), new_eta1)) + old_lp1;
        old_like_lambda += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
      }else if(option(j) == 2){
        new_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
        old_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
      }
    }//end Calculate likelihood
    
    num = new_like_eta + std::log(truncated_normal_a_pdf(old_eta1, new_eta1, jump_eta1, 0)) + R::dgamma(new_eta1, pr_shape_eta, pr_scale_eta, 1);
    den = old_like_eta + std::log(truncated_normal_a_pdf(new_eta1, old_eta1, jump_eta1, 0)) + R::dgamma(old_eta1, pr_shape_eta, pr_scale_eta, 1);
    
    ratio = num - den;
    
    if(ratio > 0.0) accept = 1;
    else{
      un = R::runif(0,1);
      if(std::log(un) < ratio) accept = 1;
      else accept = 0;
    }
    
    if(accept == 1){
      old_eta1 = new_eta1;
      accept_eta1 += 1.0 / (niter * 1.0);
    }else new_eta1 = old_eta1;
    
    //update eta2
    new_eta2 = truncated_normal_a_sample(old_eta2, jump_eta2, 0, seed);
    old_like_eta = new_like_eta = 0.0;
    
    //Calculate likelihood
    for(j = 0; j < n; j++){
      
      old_lp2 = 0;
      old_lp1 = 0;
      
      old_lp1 = oldlambda1(0) * a(j) * w(j) + (oldlambda1(1) * a(j) + oldlambda1(2) *  b(j)) * (1-  w(j));
      old_lp2 = oldlambda2(0) * a(j) * w(j) + (oldlambda2(1) * a(j) + oldlambda2(2) *  b(j)) * (1-  w(j));
      
      
      new_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), new_eta2));
      old_like_lambda -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
      
      // option: (0:censored, 1:only TP, 2: only NC)
      if(option(j) == 1){ 
        new_like_lambda += std::log(new_eta1) + new_eta1 * std::log(old_gamma1) + (new_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
        old_like_lambda += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
      }else if(option(j) == 2){
        new_like_lambda += std::log(new_eta2) + new_eta2 * std::log(old_gamma2) + (new_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), new_eta2)) + old_lp2;
        old_like_lambda += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
      }    
    }//end Calculate likelihood
    
    num = new_like_eta + std::log(truncated_normal_a_pdf(old_eta2, new_eta2, jump_eta2, 0)) + R::dgamma(new_eta2, pr_shape_eta, pr_scale_eta, 1);
    den = old_like_eta + std::log(truncated_normal_a_pdf(new_eta2, old_eta2, jump_eta2, 0)) + R::dgamma(old_eta2, pr_shape_eta, pr_scale_eta, 1);
    
    ratio = num - den;
    if(ratio > 0.0) accept = 1;
    else{
      un = R::runif(0,1);
      if(std::log(un) < ratio) accept = 1;
      else accept = 0;
    }
    
    if(accept == 1){
      old_eta2 = new_eta2;
      accept_eta2 += 1.0 / (niter * 1.0);
    }else new_eta2 = old_eta2;
    
    // update gamma1
    
    new_gamma1 = truncated_normal_a_sample(old_gamma1, jump_gamma1, 0, seed);
    
    old_like_gamma = new_like_gamma = 0.0;
    
    //Calculate likelihood
    for(j = 0; j < n; j++){
      
      old_lp2 = 0;
      old_lp1 = 0;
      
      old_lp1 = oldlambda1(0) * a(j) * w(j) + (oldlambda1(1) * a(j) + oldlambda1(2) *  b(j)) * (1-  w(j));
      old_lp2 = oldlambda2(0) * a(j) * w(j) + (oldlambda2(1) * a(j) + oldlambda2(2) *  b(j)) * (1-  w(j));
      
      new_like_gamma -= std::exp(old_lp1) * std::log( 1 + pow(new_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
      old_like_gamma -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
      
      // option: (0:censored, 1:only TP, 2: only NC)
      if(option(j) == 1){ 
        new_like_gamma += std::log(old_eta1) + old_eta1 * std::log(new_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(new_gamma1 * time(j), old_eta1)) + old_lp1;
        old_like_gamma += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
      }else if(option(j) == 2){
        new_like_gamma += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
        old_like_gamma += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
      }
    }//end Calculate likelihood
    
    num = new_like_gamma + std::log(truncated_normal_a_pdf(old_gamma1, new_gamma1, jump_gamma1, 0)) + R::dgamma(new_gamma1, pr_shape_gamma, pr_scale_gamma, 1);
    den = old_like_gamma + std::log(truncated_normal_a_pdf(new_gamma1, old_gamma1, jump_gamma1, 0)) + R::dgamma(old_gamma1, pr_shape_gamma, pr_scale_gamma, 1);
    
    ratio = num - den;
    
    if(ratio > 0.0) accept = 1;
    else{
      un = R::runif(0,1);
      if(std::log(un) < ratio) accept = 1;
      else accept = 0;
    }
    
    if(accept == 1){
      old_gamma1 = new_gamma1;
      accept_gamma1 += 1.0 / (niter * 1.0);
    }else new_gamma1 = old_gamma1;
    
    //update gamma2
    
    new_gamma2 = truncated_normal_a_sample(old_gamma2, jump_gamma2, 0, seed);
    
    old_like_gamma = new_like_gamma = 0.0;
    
    //Calculate likelihood
    for(j = 0; j < n; j++){
      
      old_lp2 = 0;
      old_lp1 = 0;
      
      old_lp1 = oldlambda1(0) * a(j) * w(j) + (oldlambda1(1) * a(j) + oldlambda1(2) *  b(j)) * (1-  w(j));
      old_lp2 = oldlambda2(0) * a(j) * w(j) + (oldlambda2(1) * a(j) + oldlambda2(2) *  b(j)) * (1-  w(j));
      
      new_like_gamma -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(new_gamma2 * time(j), old_eta2));
      old_like_gamma -= std::exp(old_lp1) * std::log( 1 + pow(old_gamma1 * time(j), old_eta1)) + std::exp(old_lp2) * std::log( 1 + pow(old_gamma2 * time(j), old_eta2));
      
      // option: (0:censored, 1:only TP, 2: only NC)
      if(option(j) == 1){ 
        new_like_gamma += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
        old_like_gamma += std::log(old_eta1) + old_eta1 * std::log(old_gamma1) + (old_eta1 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma1 * time(j), old_eta1)) + old_lp1;
      }else if(option(j) == 2){
        new_like_gamma += std::log(old_eta2) + old_eta2 * std::log(new_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(new_gamma2 * time(j), old_eta2)) + old_lp2;
        old_like_gamma += std::log(old_eta2) + old_eta2 * std::log(old_gamma2) + (old_eta2 - 1) * std::log(time(j)) - std::log(1 + pow(old_gamma2 * time(j), old_eta2)) + old_lp2;
      }
    }//end Calculate likelihood
    
    num = new_like_gamma + std::log(truncated_normal_a_pdf(old_gamma2, new_gamma2, jump_gamma2, 0)) + R::dgamma(new_gamma2, pr_shape_gamma, pr_scale_gamma, 1);
    den = old_like_gamma + std::log(truncated_normal_a_pdf(new_gamma2, old_gamma2, jump_gamma2, 0)) + R::dgamma(old_gamma2, pr_shape_gamma, pr_scale_gamma, 1);
    
    ratio = num - den;
    
    if(ratio > 0.0) accept = 1;
    else{
      un = R::runif(0,1);
      if(std::log(un) < ratio) accept = 1;
      else accept = 0;
    }
    
    if(accept == 1){
      old_gamma2 = new_gamma2;
      accept_gamma2 += 1.0 / (niter * 1.0);
    }else new_gamma2 = old_gamma2;
    
    
    // burn & thin
    if(iter >= nburn && iter % nthin == 0){
      for(i = 0; i < p ; i++) samp_lambda1(count,i) = oldlambda1(i);
      for(i = 0; i < p ; i++) samp_lambda2(count,i) = oldlambda2(i);
      samp_eta1(count) = old_eta1;
      samp_eta2(count) = old_eta2;
      samp_gamma1(count) = old_gamma1;
      samp_gamma2(count) = old_gamma2;
      count++;
    }
    
    if(iter !=0 && iter % nprint == 0){
      Rprintf("Iteration: %.3u", iter + 1); 
      for(i = 0 ; i < p ; i++ ) Rprintf("% .3f ", oldlambda1(i));
      for(i = 0 ; i < p ; i++ ) Rprintf("% .3f ", oldlambda2(i));
      Rprintf("% .6f ", old_eta1);
      Rprintf("% .6f ", old_eta2);
      Rprintf("% .6f ", old_gamma1);
      Rprintf("% .6f ", old_gamma2);
      Rprintf("\n");
    }
  }
  
  Rcpp::List output;
  output["lambda1"] = samp_lambda1;
  output["lambda2"] = samp_lambda2;
  output["eta1"] = samp_eta1;
  output["eta2"] = samp_eta2;
  output["gamma1"] = samp_gamma1;
  output["gamma2"] = samp_gamma2;
  output["accept_lambda1"] = accept_lambda1;
  output["accept_lambda2"] = accept_lambda2;
  output["accept_eta1"] = accept_eta1;
  output["accept_eta2"] = accept_eta2;
  output["accept_gamma1"] = accept_gamma1;
  output["accept_gamma2"] = accept_gamma2;
  
  return(output);
}