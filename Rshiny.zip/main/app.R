#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(DT)
library(Rcpp)
library(RcppArmadillo)
library(RcppNumerical)
library(RcppEigen)
require(bslib)
library(RcppProgress)


sourceCpp("./main_cpp.cpp")
sourceCpp("./main_cpp_loglogistic.cpp")
sourceCpp("./main_cpp_exp.cpp")
sourceCpp("./main_cpp_trial.cpp")

# https://gist.github.com/jcheng5/3830244757f8ca25d4b00ce389ea41b3
withConsoleRedirect <- function(containerId, expr) {
  # Change type="output" to type="message" to catch stderr
  # (messages, warnings, and errors) instead of stdout.
  # txt <- capture.output(results <- expr, type = "output", append = TRUE)
  txt <- capture.output(results <- expr, type = "output", append = TRUE)
  if (length(txt) > 0) {
    
    insertUI(paste0("#", containerId), where = "beforeEnd",
             # insertUI(paste0("#", containerId), where = "beforeEnd",
             ui = paste0(txt, "\n", collapse = "")
    )
  }
  results
}




# Define UI for application that draws a histogram
ui <- navbarPage("Adaptive Randomization Design",
                 # titlePanel(title=div(
                 #   # img(src="logo.png", height="70px", width="70px"),
                 #   "Adaptive Randomization Design")),
                 # "Bayesian Adaptive Randomization with Competing Risk Survival Outcomes")),
                 theme = bs_theme(version = 5, bootswatch = "minty"),
                 
                 # tabPanel(title=HTML("Introduction"),
                 #          includeHTML("./html/introduction.html")
                 # ),
                 tabPanel(title=HTML("Simulation"),
                          
                          # Application title
                          # titlePanel("Simulation for 'Bayesian Adaptive Randomization with Competing Risk Survival Outcomes'"),
                          
                          # Sidebar with a slider input for number of bins
                          sidebarLayout(
                            sidebarPanel(
                              actionButton("goButton1", "Run Simulation!"),
                              actionButton("reset2", "Reset Simulation", class = "btn-warning"),
                              h6("Click the Reset button, if you rerun the simulation"),
                              h3("1. Basic Setting"),
                              numericInput("ntrial", "Number of tirals:", 1, min = 1, max = 2000),
                              numericInput("ncohortsize", "Cohort size:", 5, min = 1, max = 10),
                              h4("Number of Cohort"),
                              fluidRow(
                                column(6,style=list("padding-right: 0px;"),
                                       numericInput("ncohort1", "equal randomization", 1, min = 1, max = 30),
                                ),
                                column(6,style=list("padding-right: 0px;"),
                                       numericInput("ncohort2", "adaptive randomization", 1, min = 1, max = 30),
                                )
                              ),
                              numericInput("prob_rt", "Proportion of SE", 0.5, min = 0, max = 1),
                              h4("Distribution"),
                              fluidRow(
                                column(6,style=list("padding-right: 0px;"),
                                       selectInput("dist_temp","Event time",choices = c("log-logistic","weibull"), selected="weibull"),
                                ),
                                column(6,style=list("padding-right: 0px;"),
                                       selectInput("prob_dist_temp","Baseline hazard",choices = c("exponential","log-logistic","weibull"), selected="weibull"),
                                )
                              ),
                              h4("Cumulative Incidence Rate (CIR)"),
                              h5("For SE patient"),
                              fluidRow(
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("true_tp_se_low", "LOW (DP)", 0.3, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("true_nc_se_low", "LOW (NC)", 0.3, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("true_tp_se_std", "STD (DP)", 0.3, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("true_nc_se_std", "STD (NC)", 0.3, min = 0, max = 1)
                                )
                              ),
                              
                              
                              h5("For RE patient"),
                              fluidRow(
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("true_tp_re_std", "STD (DP)", 0.3, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("true_nc_re_std", "STD (NC)", 0.3, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("true_tp_re_high", "HIGH (DP)", 0.3, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("true_nc_re_high", "HIGH (NC)", 0.3, min = 0, max = 1)
                                )
                              ),
                              
                              
                              h3("2. Desirability weights"),
                              includeHTML("./html/event.html"),
                              fluidRow(
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire1", "Event 1", 0,  min = 0, max = 100, width = '100%')
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire2", "Event 2", 5,  min = 0, max = 100)
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire3", "Event 3", 10,  min = 0, max = 100)
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire4", "Event 4", 20,  min = 0, max = 100)
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire5", "Event 5", 100,  min = 0, max = 100, width = '100%')
                                )
                              ),
                              

                              h3("3. Interm Analysis Setting"),
                              includeHTML("./html/theta.html"),
                              fluidRow(
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("theta1", "tau (DP)", 0.95, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("theta2", "tau (NC)", 0.95, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("q1", "q (DP)", 0.4, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("q2", "q (NC)", 0.4, min = 0, max = 1)
                                )
                              ),
                              h3("\n"),
                              width = 5
                            ),
                            
                            # Show a plot of the generated distribution
                            mainPanel(width = 7,
                                      div(DT::dataTableOutput("table"), style = "font-size: 90%; width: 90%"),
                                      h6(" * '# of patient treated' means the number of pateints for each dose.")
                            )
                            
                          )
                 ), 
                 tabPanel(title=HTML("Real Trial"),
                          
                          # Application title
                          # titlePanel("Simulation for 'Bayesian Adaptive Randomization with Competing Risk Survival Outcomes'"),
                          
                          # Sidebar with a slider input for number of bins
                          sidebarLayout(
                            sidebarPanel(
                              actionButton("goButton3", "Run Real Trial!"),
                              h5("<Upload the historical Data>"),
                              span("If you have historical data, upload the file else ignore this step", style = "color:blue"),
                              br(),
                              h6("Download Input File"),
                              downloadButton('inputfile', "Download Input File"),
                              
                              fileInput("file1",  h6("Upload Input File"),
                                        multiple = FALSE,
                                        accept = c("text/csv",
                                                   "text/comma-separated-values,text/plain",
                                                   ".csv")),
                              actionButton('reset', "Reset Input File", class = "btn-warning"),
                              
                              h3("Settings"),
                              h5("<About new Patients>"),
                              fluidRow(
                                column(6,style=list("padding-right: 5px;"),
                                       numericInput("num_re", "Number of RE", 2, min = 0, max = 10)
                                ),
                                column(6,style=list("padding-left: 5px;"),
                                       numericInput("num_se", "Number of SE", 2, min = 0, max = 10)
                                )
                              ),
                              h5("<Desirability weights>"),
                              fluidRow(
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire12", "Event 1", 0,  min = 0, max = 100, width = '100%')
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire22", "Event 2", 5,  min = 0, max = 100)
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire32", "Event 3", 10,  min = 0, max = 100)
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire42", "Event 4", 20,  min = 0, max = 100)
                                ),
                                column(2,style=list("padding-right: 0px;"),
                                       numericInput("desire52", "Event 5", 100,  min = 0, max = 100, width = '100%')
                                )
                              ),
                              h5("<Interm Analysis>"),
                              fluidRow(
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("theta11", "theta1", 0.95, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("theta21", "theta2", 0.95, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-right: 5px;"),
                                       numericInput("q11", "q1", 0.4, min = 0, max = 1)
                                ),
                                column(3,style=list("padding-left: 5px;"),
                                       numericInput("q21", "q2", 0.4, min = 0, max = 1)
                                )
                              ), 
                              h5("<Terminated Dose>"),
                              fluidRow(
                                column(6,
                                       checkboxGroupInput(
                                         "term_se",
                                         h5("For SE"),
                                         choices = c('Low dose' = 'Low dose',
                                                     'Standard dose' = 'Standard dose', 
                                                     'No' = 'No'),
                                         # inline = TRUE,
                                         selected = c('No'),
                                         width = '200px'
                                       )
                                ),
                                
                                column(6,
                                       checkboxGroupInput(
                                         "term_re",
                                         h5("For RE"),
                                         choices = c('Standard dose' = 'Standard dose',
                                                     'High dose' = 'High dose', 
                                                     'No' = 'No'),
                                         # inline = TRUE,
                                         selected = c('No'),
                                         width = '200px'
                                       )
                                ) 
                              ),
                              
                              
                              width = 5
                            ),
                            
                            # Show a plot of the generated distribution
                            mainPanel(width = 7,
                                      # shinyjs::useShinyjs(),
                                      # pre(id = "console"),
                                      tags$head(tags$style("#contents2_se{color: black;
                                 font-size: 15px;
                                 # font-style: italic;
                                 }"
                                      )
                                      ),
                                 tags$head(tags$style("#contents2_re{color: black;
                                 font-size: 15px;
                                 # font-style: italic;
                                 }"
                                 )
                                 ),
                                 # verbatimTextOutput("console2"),
                                 h5("<SE>"),
                                 textOutput("contents2_se"),
                                 div(DT::dataTableOutput("contents_se"), style = "font-size: 90%; width: 90%"),
                                 h5("<RE>"),
                                 textOutput("contents2_re"),
                                 div(DT::dataTableOutput("contents_re"), style = "font-size: 90%; width: 90%")
                            )
                          )
                 ),
                 # tabPanel(title=HTML("About Us"),
                 #          # includeHTML("about.html")
                 #          htmlOutput("info")
                 # )
)  



# Define server logic required to draw a histogram
server <- function(input, output) {
  output$info <- renderUI(
    tryCatch(
      {
        includeHTML("./html/about.html")  
      },
      error = function(e){
        return()
      },
      warning = function(w){
        return()
      }
    )
  )
  storage <- reactiveValues()
  storage2 <- reactiveValues()
  storage_temp <- reactiveValues( )
  rv <- reactiveValues(data = NULL, clear = FALSE)
  niter <- 20000
  nburn <- 5000
  nthin <- 5
  
  observeEvent(input$goButton1,{
    
    nprint <- niter * 2
    true_tp_se <- c(input$true_tp_se_low, input$true_tp_se_std)
    true_tp_re <- c(input$true_tp_re_std, input$true_tp_re_high)
    true_nc_se <- c(input$true_nc_se_low, input$true_nc_se_std)
    true_nc_re <- c(input$true_nc_re_std, input$true_nc_re_high)
    desire <- c(input$desire1, input$desire2, input$desire3, input$desire4, input$desire5)
    prob_half <- rep(0.3, 4)
    jump_eta1 <- 0.5
    jump_eta2 <- 0.5
    jump_lambda1 <- c(3,3,3)
    jump_lambda2 <- c(3,3,3)
    jump_gamma1 <- 0.5
    jump_gamma2 <- 0.5
    
    pr_mean_lambda <- 0
    pr_sd_lambda <- 4
    pr_shape_eta <- 1
    pr_scale_eta <- 0.1 #scale
    pr_shape_gamma <- 1
    pr_scale_gamma <- 0.1 #scale
    
    if(input$dist_temp == "weibull"){
      dist = 1
    }else if(input$dist_temp == "log-logistic"){
      dist = 2
    }
    
    
    if(input$prob_dist_temp == "weibull"){
      
      
      storage$res_lsirm <- list()
      
      withProgress(message = 'Simulation Working', value = 0, {   
        step = input$ntrial
        for( i in 1:step){ 
          
          
          res_lsirm_temp<-competing_risk_main(1, input$ncohort1, input$ncohort2,
                                              input$ncohortsize, true_tp_se, true_tp_re,
                                              true_nc_se, true_nc_re,
                                              prob_half, niter, nburn,
                                              nthin, nprint, jump_eta1, jump_eta2,
                                              jump_lambda1, jump_lambda2, pr_mean_lambda,
                                              pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                                              pr_shape_gamma, pr_scale_gamma, input$theta1,  input$theta2,
                                              input$q1,  input$q2, desire, input$prob_rt, dist)
          
          
          if(i == 1){
            storage$res_lsirm$`rt&dose` <- res_lsirm_temp$`rt&dose`
            storage$res_lsirm$num_tpnc <- res_lsirm_temp$num_tpnc
            storage$res_lsirm$final_re_std <- res_lsirm_temp$final_re_std
            storage$res_lsirm$final_se_std <- res_lsirm_temp$final_se_std
            storage$res_lsirm$early_stop_re_high <- res_lsirm_temp$early_stop_re_high
            storage$res_lsirm$early_stop_re_std <- res_lsirm_temp$early_stop_re_std
            storage$res_lsirm$early_stop_se_std <- res_lsirm_temp$early_stop_se_std
            storage$res_lsirm$early_stop_se_low <- res_lsirm_temp$early_stop_se_low
          }else{
            storage$res_lsirm$`rt&dose` <- rbind(storage$res_lsirm$`rt&dose`, res_lsirm_temp$`rt&dose`)
            storage$res_lsirm$num_tpnc <- rbind(storage$res_lsirm$num_tpnc, res_lsirm_temp$num_tpnc)
            storage$res_lsirm$final_re_std <- c(storage$res_lsirm$final_re_std, res_lsirm_temp$final_re_std)
            storage$res_lsirm$final_se_std <- c(storage$res_lsirm$final_se_std, res_lsirm_temp$final_se_std)
            storage$res_lsirm$early_stop_re_high <- storage$res_lsirm$early_stop_re_high + res_lsirm_temp$early_stop_re_high
            storage$res_lsirm$early_stop_re_std <- storage$res_lsirm$early_stop_re_std + res_lsirm_temp$early_stop_re_std
            storage$res_lsirm$early_stop_se_std <- storage$res_lsirm$early_stop_se_std + res_lsirm_temp$early_stop_se_std
            storage$res_lsirm$early_stop_se_low <- storage$res_lsirm$early_stop_se_low + res_lsirm_temp$early_stop_se_low
          }
          
          incProgress(1/step, detail = paste(i, 'th'))
          
          
        } 
      })
      
      
    }else if(input$prob_dist_temp == "log-logistic"){
      
      storage$res_lsirm <- list()
      
      withProgress(message = 'Simulation Working', value = 0, {   
        step = input$ntrial
        for( i in 1:step){ 
          
          
          res_lsirm_temp<-competing_risk_main_log(1,  input$ncohort1,  input$ncohort2,
                                                  input$ncohortsize, true_tp_se, true_tp_re,
                                                  true_nc_se, true_nc_re,
                                                  prob_half, niter, nburn,
                                                  nthin, nprint, jump_eta1, jump_eta2, jump_gamma1, jump_gamma2,
                                                  jump_lambda1, jump_lambda2, pr_mean_lambda,
                                                  pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                                                  pr_shape_gamma, pr_scale_gamma,  input$theta1,   input$theta2,
                                                  input$q1,   input$q2, desire,  input$prob_rt, dist)
          
          
          if(i == 1){
            storage$res_lsirm$`rt&dose` <- res_lsirm_temp$`rt&dose`
            storage$res_lsirm$num_tpnc <- res_lsirm_temp$num_tpnc
            storage$res_lsirm$final_re_std <- res_lsirm_temp$final_re_std
            storage$res_lsirm$final_se_std <- res_lsirm_temp$final_se_std
            storage$res_lsirm$early_stop_re_high <- res_lsirm_temp$early_stop_re_high
            storage$res_lsirm$early_stop_re_std <- res_lsirm_temp$early_stop_re_std
            storage$res_lsirm$early_stop_se_std <- res_lsirm_temp$early_stop_se_std
            storage$res_lsirm$early_stop_se_low <- res_lsirm_temp$early_stop_se_low
          }else{
            storage$res_lsirm$`rt&dose` <- rbind(storage$res_lsirm$`rt&dose`, res_lsirm_temp$`rt&dose`)
            storage$res_lsirm$num_tpnc <- rbind(storage$res_lsirm$num_tpnc, res_lsirm_temp$num_tpnc)
            storage$res_lsirm$final_re_std <- c(storage$res_lsirm$final_re_std, res_lsirm_temp$final_re_std)
            storage$res_lsirm$final_se_std <- c(storage$res_lsirm$final_se_std, res_lsirm_temp$final_se_std)
            storage$res_lsirm$early_stop_re_high <- storage$res_lsirm$early_stop_re_high + res_lsirm_temp$early_stop_re_high
            storage$res_lsirm$early_stop_re_std <- storage$res_lsirm$early_stop_re_std + res_lsirm_temp$early_stop_re_std
            storage$res_lsirm$early_stop_se_std <- storage$res_lsirm$early_stop_se_std + res_lsirm_temp$early_stop_se_std
            storage$res_lsirm$early_stop_se_low <- storage$res_lsirm$early_stop_se_low + res_lsirm_temp$early_stop_se_low
          }
          
          
          incProgress(1/step, detail = paste(i, 'th'))
          
        } 
      })
      
      
    }else if(input$prob_dist_temp == "exponential"){
      
      
      storage$res_lsirm <- list()
      
      withProgress(message = 'Simulation Working', value = 0, {   
        step = input$ntrial
        for( i in 1:step){ 
          
          
          res_lsirm_temp<-competing_risk_main_exp(1,  input$ncohort1,  input$ncohort2,
                                                  input$ncohortsize, true_tp_se, true_tp_re,
                                                  true_nc_se, true_nc_re,
                                                  prob_half, niter, nburn,
                                                  nthin, nprint, 
                                                  jump_lambda1, jump_lambda2, pr_mean_lambda,
                                                  pr_sd_lambda, 
                                                  pr_shape_gamma, pr_scale_gamma,  input$theta1,   input$theta2,
                                                  input$q1,   input$q2, desire,  input$prob_rt, dist)
          
          
          if(i == 1){
            storage$res_lsirm$`rt&dose` <- res_lsirm_temp$`rt&dose`
            storage$res_lsirm$num_tpnc <- res_lsirm_temp$num_tpnc
            storage$res_lsirm$final_re_std <- res_lsirm_temp$final_re_std
            storage$res_lsirm$final_se_std <- res_lsirm_temp$final_se_std
            storage$res_lsirm$early_stop_re_high <- res_lsirm_temp$early_stop_re_high
            storage$res_lsirm$early_stop_re_std <- res_lsirm_temp$early_stop_re_std
            storage$res_lsirm$early_stop_se_std <- res_lsirm_temp$early_stop_se_std
            storage$res_lsirm$early_stop_se_low <- res_lsirm_temp$early_stop_se_low
          }else{
            storage$res_lsirm$`rt&dose` <- rbind(storage$res_lsirm$`rt&dose`, res_lsirm_temp$`rt&dose`)
            storage$res_lsirm$num_tpnc <- rbind(storage$res_lsirm$num_tpnc, res_lsirm_temp$num_tpnc)
            storage$res_lsirm$final_re_std <- c(storage$res_lsirm$final_re_std, res_lsirm_temp$final_re_std)
            storage$res_lsirm$final_se_std <- c(storage$res_lsirm$final_se_std, res_lsirm_temp$final_se_std)
            storage$res_lsirm$early_stop_re_high <- storage$res_lsirm$early_stop_re_high + res_lsirm_temp$early_stop_re_high
            storage$res_lsirm$early_stop_re_std <- storage$res_lsirm$early_stop_re_std + res_lsirm_temp$early_stop_re_std
            storage$res_lsirm$early_stop_se_std <- storage$res_lsirm$early_stop_se_std + res_lsirm_temp$early_stop_se_std
            storage$res_lsirm$early_stop_se_low <- storage$res_lsirm$early_stop_se_low + res_lsirm_temp$early_stop_se_low
          }
          
          incProgress(1/step, detail = paste(i, 'th'))
          
          
        } 
      })
      
    }
    
  })
  
  
  
  
  output$table <- DT::renderDataTable({
    
    if(is.null(storage$res_lsirm)){
      data_final <- data.frame(matrix(NA, ncol = 8, nrow = 5))
      colnames(data_final) <- rep(c("DP", "NC"), 4)
      row.names(data_final) <- c("CIR", "# of patient treated",
                                 "# DP, # NC", "selection probability",
                                 "early stop probability")
      
      myContainer <- htmltools::withTags(table(
        class = 'display',
        thead(
          tr(
            th(),
            th(colspan = 4, 'RE', class = "dt-center"),
            th(colspan = 4, 'SE', class = "dt-center")
          ),
          tr(
            th(),
            th(colspan = 2, 'STD', class = "dt-center"),
            th(colspan = 2, 'HIGH', class = "dt-center"),
            th(colspan = 2, 'LOW', class = "dt-center"),
            th(colspan = 2, 'STD', class = "dt-center")
          ),
          tr(
            th(),
            lapply(names(data_final), th)
          )
        )
      ))
      
      
      
      DT::datatable(data_final, container = myContainer,
                    options = list(dom = "t", ordering = FALSE,
                                   columnDefs = list(list(className = "dt-center", targets = "_all"))
                    ))
      
      
      
    }else{     
      
      
      true_tp_se <- c(input$true_tp_se_low, input$true_tp_se_std)
      true_tp_re <- c(input$true_tp_re_std, input$true_tp_re_high)
      true_nc_se <- c(input$true_nc_se_low, input$true_nc_se_std)
      true_nc_re <- c(input$true_nc_re_std, input$true_nc_re_high)
      a <- c(true_tp_re[1], true_nc_re[1], true_tp_re[2], true_nc_re[2],
             true_tp_se[1], true_nc_se[1], true_tp_se[2], true_nc_se[2])
      
      b <- c(round(apply(storage$res_lsirm$`rt&dose`, 2, mean), 3)[1], NA,
             round(apply(storage$res_lsirm$`rt&dose`, 2, mean), 3)[2], NA,
             round(apply(storage$res_lsirm$`rt&dose`, 2, mean), 3)[3], NA,
             round(apply(storage$res_lsirm$`rt&dose`, 2, mean), 3)[4], NA)
      e <- round(apply(storage$res_lsirm$num_tpnc, 2, mean), 2)
      c <- round(c(table(c(storage$res_lsirm$final_re_std))[c('1')]/input$ntrial*100, NA,
                   table(c(storage$res_lsirm$final_re_std))[c('2')]/input$ntrial*100, NA,
                   table(c(storage$res_lsirm$final_se_std))[c('0')]/input$ntrial*100, NA,
                   table(c(storage$res_lsirm$final_se_std))[c('1')]/input$ntrial*100, NA), 2)
      c[is.na(c)] <- 0
      d <- c(storage$res_lsirm$early_stop_re_std/input$ntrial * 100, NA,
             storage$res_lsirm$early_stop_re_high/input$ntrial * 100,NA,
             storage$res_lsirm$early_stop_se_low/input$ntrial * 100, NA,
             storage$res_lsirm$early_stop_se_std/input$ntrial * 100, NA )
      data_final <- data.frame(rbind(a, b, e, c, d))
      colnames(data_final) <- rep(c("DP", "NC"), 4)
      row.names(data_final) <- c("CIR", "# of patient treated",
                                 "# DP, # NC", "selection probability",
                                 "early stop probability")
      
      
      myContainer <- htmltools::withTags(table(
        class = 'display',
        thead(
          tr(
            th(),
            th(colspan = 4, 'RE', class = "dt-center"),
            th(colspan = 4, 'SE', class = "dt-center")
          ),
          tr(
            th(),
            th(colspan = 2, 'STD', class = "dt-center"),
            th(colspan = 2, 'HIGH', class = "dt-center"),
            th(colspan = 2, 'LOW', class = "dt-center"),
            th(colspan = 2, 'STD', class = "dt-center")
          ),
          tr(
            th(),
            lapply(names(data_final), th)
          )
        )
      ))
      
      
      
      
      DT::datatable(data_final, container = myContainer,
                    options = list(dom = "t", ordering = FALSE,
                                   columnDefs = list(list(className = "dt-center", targets = "_all"))
                    ))
    }
    
    
  })
  

  
  a <- data.frame("RSS" = c(1), "dose" = c(1), "event" = c(1), "time" = c(1))
  
  output$inputfile = downloadHandler(
    filename = 'input.csv',
    content = function(filename){
      write.csv(a, filename, row.names = F)
    }
  )
  
  
  
  observe({
    req(input$file1)
    req(!rv$clear)
    
    rv$data <- read.csv(input$file1$datapath)
    
  })
  
  
  observeEvent(input$file1, {
    rv$clear <- FALSE
  }, priority = 1000)
  
  observeEvent(input$reset, {
    rv$data <- NULL
    rv$clear <- TRUE
    shinyjs::reset('file1')
  }, priority = 1000)
  
  observeEvent(input$reset2, {
    storage$res_lsirm <- NULL
  }, priority = 1000)
  
  
  se_low_func <- reactive({
    if(sum(input$term_se %in% c('Low dose')) == 1){
      se_low <- TRUE
    }else{
      se_low <- FALSE
    }
    print(se_low)
    return(se_low)
  })
  
  se_std_func <- reactive({
    if((input$term_se %in% c('Standard dose'))){
      se_std <- TRUE
    }else{
      se_std <- FALSE
    }
    return(se_std)
  })
  
  re_std_func <- reactive({
    if((input$term_re %in% c('Standard dose'))){
      re_std <- TRUE
    }else{
      re_std <- FALSE
    }
    return(re_std)
  })
  
  re_high_func <- reactive({
    if((input$term_re %in% c('High dose'))){
      re_high <- TRUE
    }else{
      re_high <- FALSE
    }
    return(re_high)
  })
  
  
  observeEvent(input$goButton3,{
    
    data_final_re <- data.frame(matrix(NA, nrow = input$num_re, ncol = 2))
    colnames(data_final_re) <- c("ID", "Dose")
    
    data_final_se <- data.frame(matrix(NA, nrow = input$num_se, ncol = 2))
    colnames(data_final_se) <- c("ID", "Dose")
    
    storage_temp$text_re <- NULL
    storage_temp$text_re <- NULL
    
    desire <- c(input$desire12, input$desire22, input$desire32, input$desire42, input$desire52)
    prob_half <- rep(0.3, 4)
    # prob_half <- rep(input$prob_half2, 4)
    jump_eta1 <- 0.5
    jump_eta2 <- 0.5
    jump_lambda1 <- c(3,3,3)
    jump_lambda2 <- c(3,3,3)
    
    pr_mean_lambda <- 0
    pr_sd_lambda <- 4
    pr_shape_eta <- 1
    pr_scale_eta <- 0.1 #scale
    pr_shape_gamma <- 1
    pr_scale_gamma <- 0.1 #scale
    
    # desire <- c(0, 5, 10, 20, 100)
    # input <- data.frame(theta11 = 0.4, theta21= 0.4, q11 = 0.95, q21 = 0.95 )
    
    
    if(!is.null(rv$data)){
      
      # df <- data_original()
      df <- rv$data
      
      if(nrow(df) > 20){
        
        
        se_low <- se_low_func()
        se_std <- se_std_func()
        re_std <- re_std_func()
        re_high <- re_high_func()
        
        print(se_low)
        print(se_std)
        print(re_std)
        print(re_high)
        
        storage2$res_lsirm = competing_risk_realtrial(as.matrix(df), niter, nburn,
                                                      nthin, niter * 2, jump_eta1, jump_eta2,
                                                      jump_lambda1, jump_lambda2, pr_mean_lambda,
                                                      pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                                                      pr_shape_gamma, pr_scale_gamma, input$theta11,  input$theta21,
                                                      input$q11,  input$q21, desire, 1,
                                                      se_low, se_std, re_std, re_high)
        
        if(storage2$res_lsirm$ar_check_re_std == 1 & storage2$res_lsirm$ar_check_re_high == 1){
          result_re <- rep(input$num_re, NA)
        }else if(storage2$res_lsirm$ar_check_re_std == 1 & storage2$res_lsirm$ar_check_re_high == 0){
          result_re <- rbinom(input$num_re, 1, 1)
        }else if(storage2$res_lsirm$ar_check_re_std == 0 & storage2$res_lsirm$ar_check_re_high == 1){
          result_re <- rbinom(input$num_re, 1, 0)
        }else{
          result_re <- rbinom(input$num_re, 1, storage2$res_lsirm$prob_re_std)
        }
        
        
        if(storage2$res_lsirm$ar_check_se_low == 1 & storage2$res_lsirm$ar_check_se_std == 1){
          result_se <- rep(input$num_se, NA)
        }else if(storage2$res_lsirm$ar_check_se_low == 1 & storage2$res_lsirm$ar_check_se_std == 0){
          result_se <- rbinom(input$num_se, 1, 1)
        }else if(storage2$res_lsirm$ar_check_se_low == 0 & storage2$res_lsirm$ar_check_se_std == 1){
          result_se <- rbinom(input$num_se, 1, 0)
        }else{
          result_se <- rbinom(input$num_se, 1, storage2$res_lsirm$prob_re_std)
        }
        
        
        
        if(storage2$res_lsirm$ar_check_se_low == 1 & storage2$res_lsirm$ar_check_se_std == 1){
          storage_temp$text_se <- paste0("Terminate the trial for SE patient")
        }else if(storage2$res_lsirm$ar_check_se_low == 1 & storage2$res_lsirm$ar_check_se_std == 0){
          storage_temp$text_se <- paste0("Low Dose is not admissible (All SE patients assigned to standard dose)")
        }else if(storage2$res_lsirm$ar_check_se_low == 0 & storage2$res_lsirm$ar_check_se_std == 1){
          storage_temp$text_se <- paste0("Standard Dose is not admissible (All SE patients assigned to low dose)")
        }else{
          storage_temp$text_se <- paste0("Adaptive Randomization")
        }
        
        if(storage2$res_lsirm$ar_check_re_std == 1 & storage2$res_lsirm$ar_check_re_high == 1){
          storage_temp$text_re <- paste0("Terminate the trial for RE patient")
        }else if(storage2$res_lsirm$ar_check_re_std == 1 & storage2$res_lsirm$ar_check_re_high == 0){
          storage_temp$text_re <- paste0("Standard Dose is not admissible (All RE patients assigned to high dose)")
        }else if(storage2$res_lsirm$ar_check_re_std == 0 & storage2$res_lsirm$ar_check_re_high == 1){
          storage_temp$text_re <- paste0("High Dose is not admissible (All RE patients assigned to standard dose)")
        }else{
          storage_temp$text_re <- paste0("Adaptive Randomization")
        }
        
        
      }else{
        
        se_low <- se_low_func()
        se_std <- se_std_func()
        re_std <- re_std_func()
        re_high <- re_high_func()
        
        if(se_low == TRUE){
          result_se <- rbinom(input$num_se, 1, 1)
        }else if(se_std == TRUE){
          result_se <- rbinom(input$num_se, 1, 0)
        }else if(se_low == TRUE & se_std == TRUE){
          result_se <- 9
        }else{
          result_se <- rbinom(input$num_se, 1, 0.5)
        }
        
        if(re_std == TRUE){
          result_re <- rbinom(input$num_re, 1, 1)
        }else if(re_high == TRUE){
          result_re <- rbinom(input$num_re, 1, 0)
        }else if(re_std == TRUE & re_high == TRUE){
          result_re <- 9
        }else{
          result_re <- rbinom(input$num_re, 1, 0.5)
        }
        
        storage_temp$text_re <- paste0("Equal Randomization")
        storage_temp$text_se <- paste0("Equal Randomization")
        # result_re <- rbinom(input$num_re, 1, 0.5)
        # result_se <- rbinom(input$num_se, 1, 0.5)
      }
      
      
    }else{
      storage_temp$text_re <- paste0("Equal Randomization")
      storage_temp$text_se <- paste0("Equal Randomization")
      result_re <- rbinom(input$num_re, 1, 0.5)
      result_se <- rbinom(input$num_se, 1, 0.5)
    }
    
    data_final_re$ID <- 1:(input$num_re)
    data_final_re$Dose <- ifelse(result_re == 1, "STD",
                                 ifelse(result_re == 9, "No Dose", "high"))
    
    
    data_final_se$ID <- 1:(input$num_se)
    data_final_se$Dose <- ifelse(result_se == 1, "STD",
                                 ifelse(result_se == 9, "No Dose", "Low"))
    
    
    storage_temp$data_final_re <- data_final_re
    storage_temp$data_final_se <- data_final_se
    
    
    
    
    
  })
  
  
  output$contents_re <- DT::renderDataTable({
    
    if(is.null(storage_temp$data_final_re)){
      data_final <- data.frame(matrix(NA, nrow = input$num_re, ncol = 2))
      colnames(data_final) <- c("ID", "Dose")
    }else{
      data_final <- storage_temp$data_final_re
    }
    
    DT::datatable(data_final,
                  options = list(dom = "t", ordering = FALSE,
                                 columnDefs = list(list(className = "dt-center", targets = "_all"))
                  ))
  })
  
  
  
  output$contents_se <- DT::renderDataTable({
    
    if(is.null(storage_temp$data_final_se)){
      data_final <- data.frame(matrix(NA, nrow = input$num_se, ncol = 2))
      colnames(data_final) <- c("ID", "Dose")
    }else{
      data_final <- storage_temp$data_final_se
    }
    
    DT::datatable(data_final,
                  options = list(dom = "t", ordering = FALSE,
                                 columnDefs = list(list(className = "dt-center", targets = "_all"))
                  ))
  })
  
  
  output$contents2_re <- renderText({
    if(is.null(storage_temp$text_re)){
      paste0("")
    }else{
      storage_temp$text_re
    }
  })
  
  output$contents2_se <- renderText({
    if(is.null(storage_temp$text_se)){
      paste0("")
    }else{
      storage_temp$text_se
    }
  })
}


# Run the application
shinyApp(ui = ui, server = server)

