# current_path <-rstudioapi::getActiveDocumentContext()$path
# setwd(dirname(current_path ))


# Inital Setting -------------

Rcpp::sourceCpp('main_cpp.cpp')
ntrial <- 1000
ncohort1 <- 4
ncohort2 <- 16
ncohortsize <- 5

prob_half <- rep(0.3,4)

niter    <- 30000
nburn    <- 10000
nthin    <- 5
nprint   <- 65000


jump_eta1 <- 0.5
jump_eta2 <- 0.5
jump_lambda1 <- c(3,3,3)
jump_lambda2 <- c(3,3,3)

pr_mean_lambda <- 0
pr_sd_lambda <- 4
pr_shape_eta <- 1
pr_scale_eta <- 0.1 #scale
pr_shape_gamma <- 1
pr_scale_gamma <- 0.1 #scale
theta1 <- 0.4
theta2 <- 0.4
q1 <- 0.95
q2 <- 0.95
desire <- c(0, 5, 10, 20, 100)
prob_rt <- 0.5
dist = 1

# Simulation Setting -------------
scenario = 5

if(scenario ==1){
  true_tp_se <- c(0.30, 0.20) # SE for TP: lower dose 0.3, standard dose 0.2
  true_tp_re <- c(0.20, 0.10) # RE for TP: standard dose 0.2, high dose 0.1
  true_nc_se <- c(0.10, 0.20) # SE for NC: lower dose 0.1, standard dose 0.2
  true_nc_re <- c(0.20, 0.30) # RE for NC: standard dose 0.2, high dose 0.3
}else if(scenario ==2){
  # # Scenario 2/60
  true_tp_se <- c(0.25, 0.10)
  true_tp_re <- c(0.30, 0.05)
  true_nc_se <- c(0.20, 0.30)
  true_nc_re <- c(0.10, 0.20)
}else if(scenario ==3){
  # Scenario 3
  true_tp_se <- c(0.60, 0.20)
  true_tp_re <- c(0.30, 0.20)
  true_nc_se <- c(0.10, 0.60)
  true_nc_re <- c(0.10, 0.60)
}else if(scenario ==4){
  # Scenario 4
  true_tp_se <- c(0.25, 0.20)
  true_tp_re <- c(0.30, 0.20)
  true_nc_se <- c(0.10, 0.60)
  true_nc_re <- c(0.10, 0.60)
}else if(scenario ==5){
  # Scenario 5
  true_tp_se <- c(0.60, 0.20)
  true_tp_re <- c(0.30, 0.05)
  true_nc_se <- c(0.10, 0.20)
  true_nc_re <- c(0.10, 0.20)
}else if(scenario ==6){
  # Scenario 6
  true_tp_se <- c(0.10, 0.08)
  true_tp_re <- c(0.50, 0.10)
  true_nc_se <- c(0.05, 0.35)
  true_nc_re <- c(0.10, 0.15)
}else if(scenario ==7){
  # # Scenario 7
  true_tp_se <- c(0.50, 0.10)
  true_tp_re <- c(0.15, 0.10)
  true_nc_se <- c(0.05, 0.35)
  true_nc_re <- c(0.10, 0.15)
}else if(scenario ==8){
  # # Scenario 8
  true_tp_se <- c(0.3, 0.2)
  true_tp_re <- c(0.2, 0.1)
  true_nc_se <- c(0.1, 0.3)
  true_nc_re <- c(0.05, 0.3)
}





start <- Sys.time()
test <- competing_risk_main(1, 1, 2,
                            ncohortsize, true_tp_se, true_tp_re,
                            true_nc_se, true_nc_re,
                            prob_half, niter, nburn,
                            nthin, nprint, jump_eta1, jump_eta2,
                            jump_lambda1, jump_lambda2, pr_mean_lambda,
                            pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                            pr_shape_gamma, pr_scale_gamma, theta1,  theta2,
                            q1,  q2, desire, prob_rt, dist)
end <- Sys.time()

save.image(paste("scenario_", 5, "_trial_",ntrial,".RData",sep = ""))
nreal <- (niter - nburn)/nthin




a <- c(ifelse(test$rt == 0, "RE", "SE"))
b <- c(ifelse(test$dose == 0, "low", ifelse(test$dose == 1, "std", "high")))
c <- c(ifelse(test$outcome == 1, 1, 0)) # TP
d <- c(ifelse(test$outcome == 2, 1, 0)) # NC
e <- c(test$event_time)
f <- c(rep(0, 15), rep(apply(test$util_value_se_low[, , 1], 2, mean), each =5))
i <- c(rep(0, 15), rep(apply(test$util_value_se_std[, , 1], 2, mean), each =5))
j <- c(rep(0, 15), rep(test$prob_se_std, each = 5))
k <- c(rep(0, 15),rep(apply(test$util_value_re_std[, , 1], 2, mean), each =5))
l <- c(rep(0, 15),rep(apply(test$util_value_re_high[, , 1], 2, mean), each =5))
m <- c(rep(0, 15),rep(test$prob_re_std, each =5))

if(test$early_stop_se_low_cohort[[1]] != 0){
  test$stop_se_low_tp[(test$early_stop_se_low_cohort + 2):16] <- nreal 
  test$stop_se_low_nc[(test$early_stop_se_low_cohort + 2):16] <- nreal 
} 
if(test$early_stop_se_std_cohort[[1]] != 0){
  test$stop_se_std_tp[(test$early_stop_se_std_cohort + 2):16] <- nreal 
  test$stop_se_std_nc[(test$early_stop_se_std_cohort + 2):16] <- nreal 
} 
if(test$early_stop_re_std_cohort[[1]] != 0){
  test$stop_re_std_tp[(test$early_stop_re_std_cohort + 2):16] <- nreal 
  test$stop_re_std_nc[(test$early_stop_re_std_cohort + 2):16] <- nreal 
} 
if(test$early_stop_re_high_cohort[[1]] != 0){
  test$stop_re_high_tp[(test$early_stop_re_high_cohort + 2):16] <- nreal 
  test$stop_re_high_nc[(test$early_stop_re_high_cohort + 2):16] <- nreal 
} 

n <- c(rep(0, 15), rep((test$stop_se_low_tp/nreal)[1, ], each = 5), rep(0, 5)) # 1 : stop (early stop at cohort test$early_stop_re_high_cohort + 1)
o <- c(rep(0, 15), rep((test$stop_se_low_nc/nreal)[1, ], each = 5), rep(0, 5))
p <- c(rep(0, 15), rep((test$stop_se_std_tp/nreal)[1, ], each =5), rep(0, 5))
q <- c(rep(0, 15), rep((test$stop_se_std_nc/nreal)[1, ], each =5), rep(0, 5))

r <- c(rep(0, 15), rep((test$stop_re_std_tp/nreal)[1, ], each =5), rep(0, 5))
s <- c(rep(0, 15), rep((test$stop_re_std_nc/nreal)[1, ], each =5), rep(0, 5))
t <- c(rep(0, 15), rep((test$stop_re_high_tp/nreal)[1, ], each =5), rep(0, 5))
u <- c(rep(0, 15), rep((test$stop_re_high_nc/nreal)[1, ], each =5), rep(0, 5))

length(f)

library(xtable)
# https://stat.ethz.ch/pipermail/r-help/2010-July/247006.html
do.multirow<-function(df, which=c(1, 7:ncol(df))){
  for(c in which){
    runs <- rle(as.character(df[,c]))
    if(all(runs$lengths>1)){
      tmp <- rep("", nrow(df))
      tmp[c(1, 1+head(cumsum(runs$lengths),-
                        1))] <-
        paste("\\multirow{",runs$lengths,"}{*}{",df[c(1,
                                                      1+head(cumsum(runs$lengths),-1)),c],"}",sep="")
      df[,c] <- tmp
    }
  }
  return(df)
}


data <- data.frame(cohort = rep(1:20, each = 5), a, b, factor(round(c, 0)), factor(round(d, 0)),
                   e, f, i, j, k , l, m,
                   n, o, p, q, r, s, t, u )
data[, 6:20] <- round(data[, 6:20], 3)
data2 <- data[order( data$cohort, data$a),]
print(xtable(data2), include.rownames=FALSE)

print(xtable(do.multirow(data2)),  include.rownames=FALSE,
      sanitize.text.function = function(x){
        return(x)
      }
)

print(xtable(do.multirow(data2[data2$cohort==16,])),  include.rownames=FALSE,
      sanitize.text.function = function(x){
        return(x)
      }
)

print(xtable(do.multirow(data2[data2$cohort==17,])),  include.rownames=FALSE,
      sanitize.text.function = function(x){
        return(x)
      }
)

print(xtable(do.multirow(data2[data2$cohort==18,])),  include.rownames=FALSE,
      sanitize.text.function = function(x){
        return(x)
      }
)

print(xtable(do.multirow(data2[data2$cohort==19,])),  include.rownames=FALSE,
      sanitize.text.function = function(x){
        return(x)
      }
)

print(xtable(do.multirow(data2[data2$cohort==20,])),  include.rownames=FALSE,
      sanitize.text.function = function(x){
        return(x)
      }
)



## Draw plot
# https://stats.stackexchange.com/questions/287181/plotting-survival-times

test$dose
test$rt
test$outcome
test$event_time
test$enter_time

# data <- data.frame(ID = 1:100, agestart = c(test$enter_time),
#                    agestop = c(test$enter_time) + c(test$event_time),
#                    event = as.factor(c(test$outcome)))

data2 <- data.frame(ID = 1:100, agestart = c(test$enter_time),
                   agestop = c(test$enter_time) + c(test$event_time),
                   event = as.factor(c(test$outcome)),
                   rt = rep(test$rt + 1),
                   dose = rep(test$dose))


data2 <- data2[order(data2$agestart, data2$rt),]
temp <- data.frame(ID = unique(data2$ID), new_id = 1:100)
data2 <- full_join(data2, temp, key = "ID")

data = data2[, c("new_id", "agestart", "agestop", "event")]
colnames(data)[1] <- "ID"

library(reshape2)
DF.long<-reshape(data, 
                    v.names = 'age', 
                    varying = c('agestart', 'agestop'), 
                    timevar = 'Timepoint', 
                    times = c('Start', 'Stop'), 
                    direction = 'long')
DF.long$dose = as.factor(data2$dose)
DF.long$rt = as.factor(data2$rt)


library(ggplot2)

DF.long$event <- ifelse(DF.long$event == 0, "Censored",
       ifelse(DF.long$event == 1, "TP", "NC"))
DF.long$dose <- ifelse(DF.long$dose == 0, "low",
                        ifelse(DF.long$dose == 1, "std", "high"))
DF.long$dose2 <- DF.long$dose
DF.long[DF.long$Timepoint == "Start", "dose2"] <- "0"
DF.long$rt <- ifelse(DF.long$rt == 1, "RE", "SE")

g1<-ggplot(aes(y=id, x=age, group =id), data=DF.long)
g2<-g1+geom_line(aes(linetype = rt, col = dose))
g3<-g2+geom_point(aes(shape=event, col = dose2), data = DF.long[DF.long$Timepoint == "Stop",])
g4<-g3+ggtitle('Survival Time (Total)')
g5<-g4+xlab('Time')
g6<-g5+ylab('ID')+ ylim(c(0, 100)) + labs(col="Dose",shape="Event", linetype = "Dose")
g6



# ## Seperate 
data_re <- data[data2$rt == 1, ]
data_se <- data[data2$rt == 2, ]
DF.long_se<-reshape(data_se,
                    v.names = 'age',
                    varying = c('agestart', 'agestop'),
                    timevar = 'Timepoint',
                    times = c('Start', 'Stop'),
                    direction = 'long')

DF.long_se$event <- ifelse(DF.long_se$event == 0, "Censored",
                        ifelse(DF.long_se$event == 1, "TP", "NC"))
DF.long_se$dose = data2$dose[data2$rt == 2]
DF.long_se$dose <- ifelse(DF.long_se$dose == 0, "low","std")
DF.long_se$dose2 <- DF.long_se$dose
DF.long_se[DF.long_se$Timepoint == "Start", "dose2"] <- "0"
DF.long_se$rt <- 2


# DF.long_se = rep(test$dose[test$rt == 0], times = 2)
# DF.long_se$rt = as.factor(rep(test$rt[test$rt == 0] + 1, times = 2))
# DF.long_se$dose2 <- DF.long_se$dose
# DF.long_se[DF.long_se$Timepoint == "Start", "dose2"] <- 0

DF.long_re<-reshape(data_re,
                    v.names = 'age',
                    varying = c('agestart', 'agestop'),
                    timevar = 'Timepoint',
                    times = c('Start', 'Stop'),
                    direction = 'long')

DF.long_re$event <- ifelse(DF.long_re$event == 0, "Censored",
                           ifelse(DF.long_re$event == 1, "TP", "NC"))
DF.long_re$dose = data2$dose[data2$rt == 1]
DF.long_re$dose <- ifelse(DF.long_re$dose == 1, "std","high")
DF.long_re$dose2 <- DF.long_re$dose
DF.long_re[DF.long_re$Timepoint == "Start", "dose2"] <- "0"
DF.long_re$rt <- 1


# DF.long_re$dose = rep(test$dose[test$rt == 1], times = 2)
# DF.long_re$rt = as.factor(rep(test$rt[test$rt == 1] + 1, times = 2))
# DF.long_re$dose2 <- DF.long_re$dose
# DF.long_re[DF.long_re$Timepoint == "Start", "dose2"] <- 0

g1<-ggplot(aes(y=ID, x=age, group =ID), data=DF.long_se)
g2<-g1+geom_line(aes( col = dose), data = DF.long_se)
g3<-g2+geom_point(aes(shape=event, col = dose2), data = DF.long_se[DF.long_se$Timepoint == "Stop",])
g4<-g3+ggtitle('Survival Time (SE)')
g5<-g4+xlab('Time')
g6<-g5+ylab('ID') + ylim(c(0, 100)) + labs(col="Dose",shape="Event")
g6

g1<-ggplot(aes(y=ID, x=age, group =ID), data=DF.long_re)
g2<-g1+geom_line(aes(col = dose), data = DF.long_re)
g3<-g2+geom_point(aes(shape=event, col = dose2), data = DF.long_re[DF.long_re$Timepoint == "Stop",])
g4<-g3+ggtitle('Survival Time (RE)')
g5<-g4+xlab('Time')
g6<-g5+ylab('ID')+ ylim(c(0, 100)) + labs(col="Dose",shape="Event")
g6



