// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppNumerical)]]
// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(RcppProgress)]]
// [[Rcpp::plugins(cpp11)]]

#define EIGEN_PERMANENTLY_DISABLE_STUPID_WARNINGS

# include "competing_weibull.cpp"
# include "generate_outcome_cpp.cpp"
# include "utility_function.cpp"
# include <RcppNumerical.h>
# include <RcppArmadillo.h>


#include <progress.hpp>
#include <progress_bar.hpp>
using namespace arma;


// [[Rcpp::export]]
Rcpp::List competing_risk_realtrial(arma::dmat data, const int niter, const int nburn,
                               const int nthin, const int nprint, double jump_eta1, double jump_eta2,
                               arma::dvec jump_lambda1, arma::dvec jump_lambda2, double pr_mean_lambda, 
                               double pr_sd_lambda, double pr_shape_eta, double pr_scale_eta,
                               double pr_shape_gamma, double pr_scale_gamma, double theta1, double theta2,
                               double q1, double q2, arma::dvec desire, double dist,
                               bool se_low, bool se_std, bool re_std, bool re_high){
  
  
  int i, real_iter, iter, total_eval_time = 6;
  double eta1, eta2, gamma1, gamma2, prob_se = 0.5, prob_re = 0.5;
  
  int n = data.n_rows;
  arma::vec model_w(n, fill::randu);
  arma::vec model_a(n, fill::zeros);
  arma::vec model_b(n, fill::zeros);
  arma::vec model_x(n, fill::zeros);
  arma::vec current_delta(n, fill::zeros);
  
  Rcpp::List output_mcmc;
  
  
  real_iter = (niter-nburn)/nthin;
  arma::mat output_lambda1;
  arma::mat output_lambda2;
  arma::mat output_eta1;
  arma::mat output_eta2;
  arma::mat output_gamma1;
  arma::mat output_gamma2;
  
  

  
  
  double ar_check_se_low = 0, ar_check_se_std = 0, ar_check_re_std = 0, ar_check_re_high = 0;
  double stop_se_low_tp = 0,  stop_se_std_tp = 0, stop_se_low_nc = 0, stop_se_std_nc = 0, stop_re_high_tp = 0, stop_re_std_tp = 0, stop_re_std_nc = 0, stop_re_high_nc = 0;
 
 if(se_low == TRUE){
   ar_check_se_low = 1;
 }
 if(se_std == TRUE){
   ar_check_se_std = 1;
 }
 if(re_std == TRUE){
   ar_check_re_std = 1;
 }
 if(re_high == TRUE){
   ar_check_re_high = 1;
 }
 
 
 
  arma::dvec util_value_se_low(real_iter, fill::zeros);
  arma::dvec util_value_se_std(real_iter, fill::zeros);
  arma::dvec util_value_re_std(real_iter, fill::zeros);
  arma::dvec util_value_re_high(real_iter, fill::zeros);
  arma::dmat util_value_se_low2(5, real_iter, fill::zeros);
  arma::dmat util_value_se_std2(5, real_iter, fill::zeros);
  arma::dmat util_value_re_std2(5, real_iter, fill::zeros);
  arma::dmat util_value_re_high2(5, real_iter, fill::zeros);
  
  arma::mat model_stop_util(real_iter, 8, fill::zeros);
  arma::dvec model_lambda_tp(3, fill::zeros);
  arma::dvec model_lambda_nc(3, fill::zeros);
  // double model_eta_tp, model_eta_nc, model_gamma_tp, model_gamma_nc;
  
  arma::dvec lambda1(3, fill::zeros);
  arma::dvec lambda2(3, fill::zeros);
  
  
  model_w.zeros();
  model_a.zeros();
  model_b.zeros();
  model_x.zeros();
  
  // data: data.frame("RSS" = c(1), "dose" = c(1), "event" = c(1), "time" = c(1))
  for(i = 0; i < n; i++){
    model_x(i) = data(i, 3);
    current_delta(i) = data(i, 2); // 0: censored/ 1: dp / 2: nc
    model_w(i) = data(i, 0); // 1: SE / 0: RE
    if(data(i, 1) == 0){
      // low
      model_a(i) = 0;
      model_b(i) = 0;
    }else if(data(i, 1) == 1){
      // std
      model_a(i) = 1;
      model_b(i) = 0;
    }else if(data(i, 1) == 2){
      // high
      model_a(i) = 0;
      model_b(i) = 1;
    }
  }
  
  
  output_mcmc = comp_weibull_new(model_x, model_w,
                                 model_a, model_b, niter, nburn, nthin,
                                 nprint, current_delta, jump_lambda1, jump_lambda2, jump_eta1,
                                 jump_eta2,  pr_mean_lambda, pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                                 pr_shape_gamma, pr_scale_gamma);
  
  // Save the estimated parameters
  
  output_lambda1 = as<arma::mat>(output_mcmc[0]);
  output_lambda2 = as<arma::mat>(output_mcmc[1]);
  output_eta1 = as<arma::vec>(output_mcmc[2]);
  output_eta2 = as<arma::vec>(output_mcmc[3]);
  output_gamma1 = as<arma::vec>(output_mcmc[4]);
  output_gamma2 = as<arma::vec>(output_mcmc[5]);
  
  
  double a = 0, b = 0;
  for(iter = 0; iter < real_iter; iter++){
    
    for(i = 0; i < 3; i++){
      lambda1(i) = output_lambda1(iter, i);
      lambda2(i) = output_lambda2(iter, i);
    }
    
    eta1 = output_eta1(iter);
    eta2 = output_eta2(iter);
    gamma1 = output_gamma1(iter);
    gamma2 = output_gamma2(iter);
    
    
    ///// SE /////////
    
    // Calculate the event occurrence probability in each interval
    util_value_se_low2.submat(0, iter, 4, iter) = integrate_utility(1, 0, 0,
                               eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
    util_value_se_std2.submat(0, iter, 4, iter) = integrate_utility(1, 1, 0,
                               eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
    
    // step 1 //
    // posterior utility //
    util_value_se_low(iter) = util_value_se_low2(0, iter) * desire(0) + util_value_se_low2(1, iter) * desire(1)+util_value_se_low2(2, iter) * desire(2)+
      util_value_se_low2(3, iter) * desire(3)+ util_value_se_low2(4, iter) * desire(4);
    
    util_value_se_std(iter) = util_value_se_std2(0, iter) * desire(0) + util_value_se_std2(1, iter) * desire(1)+util_value_se_std2(2, iter) * desire(2)+
      util_value_se_std2(3, iter) * desire(3)+ util_value_se_std2(4, iter) * desire(4);
    
    // step 2 //
    // Calculate the probability of TP occurrence by SE patients assigned to the (low, standard) dose //
    // Note: TP is related to the effectiveness of dose. 
    model_stop_util(iter, 0) = util_value_se_low2(0, iter) + util_value_se_low2(2, iter);
    if(model_stop_util(iter, 0) > theta1) stop_se_low_tp += 1; 
    
    model_stop_util(iter, 1) = util_value_se_std2(0, iter) + util_value_se_std2(2,iter);
    if(model_stop_util(iter, 1) > theta1) stop_se_std_tp += 1; 
    
    // Calculate the probability of NC occurrence by SE patients assigned to the (low, standard) dose
    // Note: NC is associated with dose toxicity.
    model_stop_util(iter, 2) = util_value_se_low2(1, iter) + util_value_se_low2(3, iter);
    if(model_stop_util(iter, 2) > theta2) stop_se_low_nc += 1; 
    
    model_stop_util(iter, 3) = util_value_se_std2(1, iter) + util_value_se_std2(3, iter);
    if(model_stop_util(iter, 3) > theta2) stop_se_std_nc += 1; 
    
    
    // step 3 //
    // Calculate dose probability using posterior utility //
    if( util_value_se_low(iter) < util_value_se_std(iter) ) a += 1;
    
    
    
    
    ///// RE //////
    util_value_re_std2.submat(0, iter, 4, iter) = integrate_utility(0, 1, 0,
                               eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
    util_value_re_high2.submat(0, iter, 4, iter) = integrate_utility(0, 0, 1,
                                eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
    
    // step 1 //
    // posterior utility //
    util_value_re_high(iter) = util_value_re_high2(0, iter) * desire(0) + util_value_re_high2(1, iter) * desire(1)+util_value_re_high2(2, iter) * desire(2)+
      util_value_re_high2(3, iter) * desire(3)+ util_value_re_high2(4, iter) * desire(4);
    
    util_value_re_std(iter) = util_value_re_std2(0, iter) * desire(0) + util_value_re_std2(1, iter) * desire(1)+util_value_re_std2(2, iter) * desire(2)+
      util_value_re_std2(3, iter) * desire(3)+ util_value_re_std2(4, iter) * desire(4);
    
    // step 2 //
    // Calculate the probability of TP occurrence by RE patients assigned to the (standard, high) dose //
    // Note: TP is related to the effectiveness of dose. 
    model_stop_util(iter, 4) = util_value_re_high2(0, iter) + util_value_re_high2(2, iter);
    if(model_stop_util(iter, 4) > theta1) stop_re_high_tp += 1; 
    
    model_stop_util(iter, 5) = util_value_re_std2(0, iter) + util_value_re_std2(2, iter);
    if(model_stop_util(iter, 5) > theta1) stop_re_std_tp += 1; 
    
    // Calculate the probability of NC occurrence by RE patients assigned to the (low, standard) dose //
    // Note: NC is related to the effectiveness of dose. 
    model_stop_util(iter, 6) = util_value_re_high2(1, iter) + util_value_re_high2(3, iter);
    if(model_stop_util(iter, 6) > theta2) stop_re_high_nc += 1; 
    
    model_stop_util(iter, 7) = util_value_re_std2(1, iter) + util_value_re_std2(3, iter);
    if(model_stop_util(iter, 7) > theta2) stop_re_std_nc+= 1; 
    
    // step 3 //
    // Calculate dose probability using posterior utility // 
    if( util_value_re_high(iter) < util_value_re_std(iter) ) b += 1;
    
  }
  
  
  prob_se = a / real_iter;
  prob_re = b / real_iter;
  
  
  ///// For SE ///////
  if((stop_se_low_tp/real_iter > q1 || stop_se_low_nc/real_iter > q2) && (stop_se_std_tp/real_iter > q1 ||stop_se_std_nc/real_iter > q2)){ // both stop
    // If low dose: stop, std dose: stop
    ar_check_se_std = 1;
    ar_check_se_low = 1;
  }else if((stop_se_low_tp/real_iter > q1 || stop_se_low_nc/real_iter > q2) && (stop_se_std_tp/real_iter < q1 && stop_se_std_nc/real_iter < q2)){ //low stop
    // If low dose: stop, std dose: stop x
    ar_check_se_low = 1;
  }else if((stop_se_low_tp/real_iter < q1 && stop_se_low_nc/real_iter < q1) && (stop_se_std_tp/real_iter > q1 ||stop_se_std_nc/real_iter > q1)){ //std stop
    // If low dose: stop x, std dose: stop 
    ar_check_se_std = 1;
  }
  
  ///// For RE ///////
  
  if((stop_re_std_nc/real_iter > q2 || stop_re_std_tp/real_iter > q1) && (stop_re_high_nc/real_iter > q2 || stop_re_high_tp/real_iter > q1)){ // both stop
    // If std dose: stop, high dose: stop
    ar_check_re_std = 1;
    ar_check_re_high = 1;
  }else if((stop_re_std_nc/real_iter > q2 || stop_re_std_tp/real_iter > q1) && (stop_re_high_nc/real_iter < q2 && stop_re_high_tp/real_iter < q1)){ //std stop
    // If std dose: stop, high dose: stop x
    ar_check_re_std = 1;
  }else if((stop_re_std_nc/real_iter < q2 && stop_re_std_tp/real_iter < q1) && (stop_re_high_nc/real_iter > q2 || stop_re_high_tp/real_iter > q1)){ //high stop
    // If std dose: stop x, high dose: stop 
    ar_check_re_high = 1;
  }
  
  
  
  

  Rcpp::List output;
  output["output_mcmc"] = output_mcmc;
  output["ar_check_se_low"] = ar_check_se_low;
  output["ar_check_se_std"] = ar_check_se_std;
  output["ar_check_re_high"] = ar_check_re_high;
  output["ar_check_re_std"] = ar_check_re_std;

  
  output["util_value_se_low"] = util_value_se_low;
  output["util_value_se_std"] = util_value_se_std;
  output["util_value_re_std"] = util_value_re_std;
  output["util_value_re_high"] = util_value_re_high;
  output["util_value_se_low2"] = util_value_se_low2;
  output["util_value_se_std2"] = util_value_se_std2;
  output["util_value_re_std2"] = util_value_re_std2;
  output["util_value_re_high2"] = util_value_re_high2;
  output["cumulative_inc_prob"] = model_stop_util;
  
  output["prob_re_std"] = prob_re;
  output["prob_se_std"] = prob_se;


  output["stop_se_std_nc"] = stop_se_std_nc;
  output["stop_se_std_tp"] = stop_se_std_tp;
  output["stop_se_low_nc"] = stop_se_low_nc;
  output["stop_se_low_tp"] = stop_se_low_tp;
  output["stop_re_std_nc"] = stop_re_std_nc;
  output["stop_re_std_tp"] = stop_re_std_tp;
  output["stop_re_high_nc"] = stop_re_high_nc;
  output["stop_re_high_tp"] = stop_re_high_tp;
  return(output);
} 


