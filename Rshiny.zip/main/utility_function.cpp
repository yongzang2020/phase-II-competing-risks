// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::depends(RcppNumerical)]]
// [[Rcpp::depends(RcppArmadillo)]]
#define EIGEN_PERMANENTLY_DISABLE_STUPID_WARNINGS
# include <RcppArmadillo.h>
# include <RcppNumerical.h>
# include <RcppEigen.h>
using namespace Numer;

class utility1: public Func
{
private:
  double w, a, b;
  double eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
public:
  utility1(double w_, double a_, double b_, double eta1_, double eta2_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), eta1(eta1_), eta2(eta2_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard1 = eta1 * pow(x, eta1 - 1) * gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w));
    double surv1 = std::exp(-gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w))* pow(x, eta1));
    double surv2 = std::exp(-gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w))* pow(x, eta2));
    
    return hazard1 * surv1 * surv2;
  }
};

class utility2: public Func
{
private:
  double w, a, b;
  double eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
  
public:
  utility2(double w_, double a_, double b_, double eta1_, double eta2_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), eta1(eta1_), eta2(eta2_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard2 = eta2 * pow(x, eta2 - 1) * gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w));
    double surv1 = std::exp(-gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w))* pow(x, eta1));
    double surv2 = std::exp(-gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w))* pow(x, eta2));
    
    return hazard2 * surv1 * surv2;
  }
};


class utility3: public Func
{
private:
  double w, a, b;
  double eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
  
public:
  utility3(double w_, double a_, double b_, double eta1_, double eta2_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), eta1(eta1_), eta2(eta2_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard1 = eta1 * pow(x, eta1 - 1) * gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w));
    double hazard2 = eta2 * pow(x, eta2 - 1) * gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w));
    double surv1 = std::exp(-gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w))* pow(x, eta1));
    double surv2 = std::exp(-gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w))* pow(x, eta2));
    
    return hazard2 * surv1 * surv2 + hazard1 * surv1 * surv2;
  }
};


// [[Rcpp::export]]
arma::dvec integrate_utility(double w, double a, double b,
                          double eta1, double eta2, double gamma1, double gamma2,
                          arma::dvec lambda1, arma::dvec lambda2,
                          double total_eval_time, double upper)
{ 
  double lambda11 = lambda1(0);
  double lambda12 = lambda1(1);
  double lambda13 = lambda1(2);
  double lambda21 = lambda2(0);
  double lambda22 = lambda2(1);
  double lambda23 = lambda2(2);
  
  utility1 f(w, a, b, eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  utility2 g(w, a, b, eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  utility3 h(w, a, b, eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  double err_est;
  int err_code;
  arma::dvec res(5);
  res(0) = integrate(f, 0, total_eval_time/2, err_est, err_code);
  res(1) = integrate(g, 0, total_eval_time/2, err_est, err_code);
  res(2) = integrate(f, total_eval_time/2, total_eval_time, err_est, err_code);
  res(3) = integrate(g, total_eval_time/2, total_eval_time, err_est, err_code);
  res(4) = integrate(h, total_eval_time, upper, err_est, err_code);
  return res;
  
}




class utility1_exp: public Func
{
private:
  double w, a, b;
  double gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
public:
  utility1_exp(double w_, double a_, double b_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard1 = gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w));
    double surv1 = std::exp(-gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w))* x);
    double surv2 = std::exp(-gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w))* x);
    
    return hazard1 * surv1 * surv2;
  }
};

class utility2_exp: public Func
{
private:
  double w, a, b;
  double gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
  
public:
  utility2_exp(double w_, double a_, double b_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_),gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard2 = gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w));
    double surv1 = std::exp(-gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w))* x);
    double surv2 = std::exp(-gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w))* x);
    
    return hazard2 * surv1 * surv2;
  }
};


class utility3_exp: public Func
{
private:
  double w, a, b;
  double gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
  
public:
  utility3_exp(double w_, double a_, double b_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard1 = gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w));
    double hazard2 = gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w));
    double surv1 = std::exp(-gamma1 * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w))* x);
    double surv2 = std::exp(-gamma2 * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w))* x);
    
    return hazard2 * surv1 * surv2 + hazard1 * surv1 * surv2;
  }
};


// [[Rcpp::export]]
arma::dvec integrate_utility_exp(double w, double a, double b,
                             double gamma1, double gamma2,
                             arma::dvec lambda1, arma::dvec lambda2,
                             double total_eval_time, double upper)
{ 
  double lambda11 = lambda1(0);
  double lambda12 = lambda1(1);
  double lambda13 = lambda1(2);
  double lambda21 = lambda2(0);
  double lambda22 = lambda2(1);
  double lambda23 = lambda2(2);
  
  utility1_exp f(w, a, b, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  utility2_exp g(w, a, b, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  utility3_exp h(w, a, b, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  double err_est;
  int err_code;
  arma::dvec res(5);
  res(0) = integrate(f, 0, total_eval_time/2, err_est, err_code);
  res(1) = integrate(g, 0, total_eval_time/2, err_est, err_code);
  res(2) = integrate(f, total_eval_time/2, total_eval_time, err_est, err_code);
  res(3) = integrate(g, total_eval_time/2, total_eval_time, err_est, err_code);
  res(4) = integrate(h, total_eval_time, upper, err_est, err_code);
  return res;
  
}




class utility1_llog: public Func
{
private:
  double w, a, b;
  double eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
public:
  utility1_llog(double w_, double a_, double b_, double eta1_, double eta2_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), eta1(eta1_), eta2(eta2_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard1 = eta1 * pow(gamma1, eta1) * pow(x, eta1 - 1) / (1 + pow(gamma1 * x, eta1)) * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w));
    double surv1 = pow(1/ (1 + pow(gamma1 * x, eta1)), exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w)));
    double surv2 = pow(1/ (1 + pow(gamma2 * x, eta2)), exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w)));
    
    return hazard1 * surv1 * surv2;
  }
};

class utility2_llog: public Func
{
private:
  double w, a, b;
  double eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
  
public:
  utility2_llog(double w_, double a_, double b_, double eta1_, double eta2_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), eta1(eta1_), eta2(eta2_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard2 = eta2 * pow(gamma2, eta2) * pow(x, eta2 - 1) / (1 + pow(gamma2 * x, eta2)) * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w));
    double surv1 = pow(1/ (1 + pow(gamma1 * x, eta1)), exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w)));
    double surv2 = pow(1/ (1 + pow(gamma2 * x, eta2)), exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w)));
    
    return hazard2 * surv1 * surv2;
  }
};


class utility3_llog: public Func
{
private:
  double w, a, b;
  double eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23;
  
public:
  utility3_llog(double w_, double a_, double b_, double eta1_, double eta2_, double gamma1_, double gamma2_,
           double lambda11_, double lambda12_, double lambda13_,
           double lambda21_, double lambda22_, double lambda23_) :
  w(w_), a(a_), b(b_), eta1(eta1_), eta2(eta2_), gamma1(gamma1_), gamma2(gamma2_),
  lambda11(lambda11_), lambda12(lambda12_), lambda13(lambda13_),
  lambda21(lambda21_), lambda22(lambda22_), lambda23(lambda23_){}
  
  
  double operator()(const double& x) const
  {
    double hazard1 = eta1 * pow(gamma1, eta1) * pow(x, eta1 - 1) / (1 + pow(gamma1 * x, eta1)) * exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w));
    double hazard2 = eta2 * pow(gamma2, eta2) * pow(x, eta2 - 1) / (1 + pow(gamma2 * x, eta2)) * exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w));
    double surv1 = pow(1/ (1 + pow(gamma1 * x, eta1)), exp(lambda11* w * a + (lambda12 * a + lambda13 * b) * (1 - w)));
    double surv2 = pow(1/ (1 + pow(gamma2 * x, eta2)), exp(lambda21* w * a + (lambda22 * a + lambda23 * b) * (1 - w)));
    
    return hazard2 * surv1 * surv2 + hazard1 * surv1 * surv2;
  }
};


// [[Rcpp::export]]
arma::dvec integrate_utility_llog(double w, double a, double b,
                             double eta1, double eta2, double gamma1, double gamma2,
                             arma::dvec lambda1, arma::dvec lambda2,
                             double total_eval_time, double upper)
{ 
  double lambda11 = lambda1(0);
  double lambda12 = lambda1(1);
  double lambda13 = lambda1(2);
  double lambda21 = lambda2(0);
  double lambda22 = lambda2(1);
  double lambda23 = lambda2(2);
  
  utility1_llog f(w, a, b, eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  utility2_llog g(w, a, b, eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  utility3_llog h(w, a, b, eta1, eta2, gamma1, gamma2, lambda11, lambda12, lambda13, lambda21, lambda22, lambda23);
  double err_est;
  int err_code;
  arma::dvec res(5);
  res(0) = integrate(f, 0, total_eval_time/2, err_est, err_code);
  res(1) = integrate(g, 0, total_eval_time/2, err_est, err_code);
  res(2) = integrate(f, total_eval_time/2, total_eval_time, err_est, err_code);
  res(3) = integrate(g, total_eval_time/2, total_eval_time, err_est, err_code);
  res(4) = integrate(h, total_eval_time, upper, err_est, err_code);
  return res;
  
}



// Examples //

// //https://cran.r-project.org/web/packages/RcppNumerical/vignettes/introduction.html
// // P(0.3 < X < 0.8), X ~ Beta(a, b)
// class BetaPDF: public Func
// {
// private:
//   double a;
//   double b;
// public:
//   BetaPDF(double a_, double b_) : a(a_), b(b_) {}
//   
//   double operator()(const double& x) const
//   {
//     return R::dbeta(x, a, b, 0);
//   }
// };
// 
// Rcpp::List integrate_test()
// {
//   const double a = 3, b = 10;
//   const double lower = 0.3, upper = 0.8;
//   const double true_val = R::pbeta(upper, a, b, 1, 0) -
//     R::pbeta(lower, a, b, 1, 0);
//   
//   BetaPDF f(a, b);
//   double err_est;
//   int err_code;
//   const double res = integrate(f, lower, upper, err_est, err_code);
//   return Rcpp::List::create(
//     Rcpp::Named("true") = true_val,
//     Rcpp::Named("approximate") = res,
//     Rcpp::Named("error_estimate") = err_est,
//     Rcpp::Named("error_code") = err_code
//   );
// }
// 
