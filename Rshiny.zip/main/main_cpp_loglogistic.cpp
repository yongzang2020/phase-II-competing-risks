// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppNumerical)]]
// [[Rcpp::depends(RcppEigen)]]
// [[Rcpp::plugins(cpp11)]]

#define EIGEN_PERMANENTLY_DISABLE_STUPID_WARNINGS

# include <RcppArmadillo.h>
# include <RcppNumerical.h>
# include "competing_loglogistic.cpp"
# include "generate_outcome_cpp.cpp"
# include "utility_function.cpp"
using namespace arma;


// [[Rcpp::export]]
Rcpp::List competing_risk_main_log(const int ntrial, const int ncohort1, const int ncohort2,
                               const int ncohortsize, arma::dvec true_tp_se, arma::dvec true_tp_re,
                               arma::dvec true_nc_se, arma::dvec true_nc_re,
                               arma::dvec prob_half, const int niter, const int nburn,
                               const int nthin, const int nprint, double jump_eta1, double jump_eta2,
                               double jump_gamma1, double jump_gamma2,
                               arma::dvec jump_lambda1, arma::dvec jump_lambda2, double pr_mean_lambda,
                               double pr_sd_lambda, double pr_shape_eta, double pr_scale_eta,
                               double pr_shape_gamma, double pr_scale_gamma, double theta1, double theta2,
                               double q1, double q2, arma::dvec desire, double prob_rt, double dist){

  int trial, cohort, coh1i, mm, total_eval_time = 6, i, real_iter, iter, coh2i;
  int early_se1 = 0, early_re1 = 0, early_se2 = 0, early_re2 = 0, num_pat = 0, se_all_stop = 0, re_all_stop = 0;
  double u, prob_tp, prob_nc, eta1, eta2, gamma1, gamma2, rt_prob, prob_se = 0.5, prob_re = 0.5;
  arma::vec model_w((ncohort1+ncohort2)*ncohortsize, fill::randu);
  arma::vec model_a((ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::vec model_b((ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::vec model_x((ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat rt1(ntrial, ncohort1*ncohortsize, fill::zeros);
  arma::mat pat_type(ntrial, 2, fill::zeros); // table: patient rt type
  arma::mat dose1(ntrial, ncohort1*ncohortsize, fill::zeros); // table: randomized patient dose list
  arma::mat patient(ntrial, 4, fill::zeros); // table: patient for each rt type & dose
  arma::vec data(4, fill::zeros);
  arma::mat y_tp1(ntrial, ncohort1*ncohortsize, fill::zeros);
  arma::mat y_nc1(ntrial, ncohort1*ncohortsize, fill::zeros);
  arma::mat tevent1(ntrial, ncohort1*ncohortsize, fill::zeros);
  arma::mat y_out1(ntrial, ncohort1*ncohortsize, fill::zeros);
  arma::mat tenter1(ntrial, ncohort1*ncohortsize, fill::zeros);
  arma::dvec time_decision(ntrial, fill::zeros);

  arma::mat rt2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat dose2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros); // randomized patient dose list
  arma::mat y_tp2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat y_nc2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat tevent2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat y_out2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat tenter2(ntrial, (ncohort1+ncohort2)*ncohortsize, fill::zeros);
  arma::mat num_tpnc(ntrial, 8, fill::zeros);

  Rcpp::List output_mcmc;
  Rcpp::List output_mcmc_list;
  Rcpp::List util_value_se_low2_list;
  Rcpp::List util_value_se_std2_list;
  Rcpp::List util_value_re_std2_list;
  Rcpp::List util_value_re_high2_list;

  real_iter = (niter-nburn)/nthin;
  arma::mat output_lambda1;
  arma::mat output_lambda2;
  arma::mat output_eta1;
  arma::mat output_eta2;
  arma::mat output_gamma1;
  arma::mat output_gamma2;

  arma::dvec ar_check_se_low(ntrial, fill::zeros);
  arma::dvec ar_check_se_std(ntrial, fill::zeros);
  arma::dvec ar_check_re_std(ntrial, fill::zeros);
  arma::dvec ar_check_re_high(ntrial, fill::zeros);
  arma::dvec ar_check_se_all(ntrial, fill::zeros);
  arma::dvec ar_check_re_all(ntrial, fill::zeros);

  arma::dmat stop_se_low_tp(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_se_std_tp(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_se_low_nc(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_se_std_nc(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_re_high_tp(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_re_std_tp(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_re_high_nc(ntrial, ncohort2, fill::zeros);
  arma::dmat stop_re_std_nc(ntrial, ncohort2, fill::zeros);

  arma::dvec ar_se_low_cohort(ntrial, fill::zeros);
  arma::dvec ar_se_std_cohort(ntrial, fill::zeros);
  arma::dvec ar_re_std_cohort(ntrial, fill::zeros);
  arma::dvec ar_re_high_cohort(ntrial, fill::zeros);
  arma::dvec ar_re_all_cohort(ntrial, fill::zeros);
  arma::dvec ar_se_all_cohort(ntrial, fill::zeros);
  arma::dcube util_value_se_low(real_iter, ncohort2 + 1, ntrial, fill::zeros);
  arma::dcube util_value_se_std(real_iter, ncohort2 + 1, ntrial, fill::zeros);
  arma::dcube util_value_re_std(real_iter, ncohort2 + 1, ntrial, fill::zeros);
  arma::dcube util_value_re_high(real_iter, ncohort2 + 1, ntrial, fill::zeros);
  arma::dcube util_value_se_low2(real_iter, 5, ncohort2 + 1, fill::zeros);
  arma::dcube util_value_se_std2(real_iter, 5, ncohort2 + 1, fill::zeros);
  arma::dcube util_value_re_std2(real_iter, 5, ncohort2 + 1, fill::zeros);
  arma::dcube util_value_re_high2(real_iter, 5, ncohort2 + 1, fill::zeros);

  arma::dcube model_stop_util(real_iter, 8, ntrial, fill::zeros);
  arma::dvec model_lambda_tp(3, fill::zeros);
  arma::dvec model_lambda_nc(3, fill::zeros);
  // double model_eta_tp, model_eta_nc, model_gamma_tp, model_gamma_nc;

  arma::dvec lambda1(3, fill::zeros);
  arma::dvec lambda2(3, fill::zeros);

  arma::dmat prob_se_std(ntrial, ncohort2 + 1, fill::zeros);
  arma::dmat prob_re_std(ntrial, ncohort2 + 1, fill::zeros);

  arma::dvec cured_pat(ntrial, fill::zeros);

  arma::dvec final_se_std(ntrial, fill::zeros);
  arma::dvec final_re_std(ntrial, fill::zeros);

  for(trial = 0; trial < ntrial; trial++){
    num_pat = 0;
    rt_prob = prob_rt;
    prob_re = 0.5;
    prob_se = 0.5;
    model_w.zeros();
    model_a.zeros();
    model_b.zeros();
    model_x.zeros();

    ////////////////////////////////////////////////

    // * 1. Allocate patients randomly * //

    for(cohort = 0; cohort < ncohort1; cohort++){
      // m: number of patient randomized before this cohort
      for(coh1i = 0; coh1i < ncohortsize; coh1i++){
        mm = cohort  * ncohortsize + coh1i;
        u = R::runif(0, 1);
        // Select RE of SE
        if(u < rt_prob){
          rt1(trial, mm) = 0; //RE
        }else rt1(trial, mm) = 1; //SE

        // Select dose level (equal randomization)
        // If RE
        if(rt1(trial, mm) == 0){
          pat_type(trial, 0) += 1;
          u = R::runif(0, 1);
          if(u < 0.5){ //Standard dose
            dose1(trial, mm) = 1;
            prob_tp = true_tp_re(0);
            prob_nc = true_nc_re(0);
            patient(trial, 0) += 1;
            model_a(mm) = 1;
            model_b(mm) = 0;
          }else{ // High dose
            dose1(trial, mm) = 2;
            prob_tp = true_tp_re(1);
            prob_nc = true_nc_re(1);
            patient(trial, 1) += 1;
            model_a(mm) = 0;
            model_b(mm) = 1;
          }
        }else{
          //If SE
          pat_type(trial, 1) += 1;
          u = R::runif(0, 1);
          if(u < 0.5){ //Low dose
            dose1(trial, mm) = 0;
            prob_tp = true_tp_se(0);
            prob_nc = true_nc_se(0);
            patient(trial, 2) += 1;
            model_a(mm) = 0;
            model_b(mm) = 0;
          }else{ //Standard dose
            dose1(trial, mm) = 1;
            prob_tp = true_tp_se(1);
            prob_nc = true_nc_se(1);
            patient(trial, 3) += 1;
            model_a(mm) = 1;
            model_b(mm) = 0;
          }
        }

        data = outcome_gen2_cpp(prob_half, prob_tp, prob_nc, rt1(trial, mm), dist, dist, 6);

        y_tp1(trial, mm) = data(1);
        y_nc1(trial, mm) = data(2);
        tevent1(trial, mm) = data(0);
        y_out1(trial, mm) = data(3);
        model_w(mm) = rt1(trial, mm);
        tenter1(trial, mm) = time_decision(trial);

        rt2(trial, mm) = rt1(trial, mm);
        dose2(trial, mm) = dose1(trial, mm);
        y_tp2(trial, mm) = y_tp1(trial, mm);
        y_nc2(trial, mm) = y_nc1(trial, mm);
        tevent2(trial, mm) = tevent1(trial, mm);
        y_out2(trial, mm) = y_out1(trial, mm);
        tenter2(trial, mm) = tenter1(trial, mm);

        if(rt1(trial, mm) == 0 &&  dose1(trial, mm) == 1 && y_out1(trial, mm) == 1) num_tpnc(trial, 0) += 1; // RE(0) & STD(1) & TP(1)
        if(rt1(trial, mm) == 0 &&  dose1(trial, mm) == 1 && y_out1(trial, mm) == 2) num_tpnc(trial, 1) += 1; // RE & STD & NC
        if(rt1(trial, mm) == 0 &&  dose1(trial, mm) == 2 && y_out1(trial, mm) == 1) num_tpnc(trial, 2) += 1; // RE & high & TP
        if(rt1(trial, mm) == 0 &&  dose1(trial, mm) == 2 && y_out1(trial, mm) == 2) num_tpnc(trial, 3) += 1; // RE & high & nc
        if(rt1(trial, mm) == 1 &&  dose1(trial, mm) == 0 && y_out1(trial, mm) == 1) num_tpnc(trial, 4) += 1; // SE & low & TP(1)
        if(rt1(trial, mm) == 1 &&  dose1(trial, mm) == 0 && y_out1(trial, mm) == 2) num_tpnc(trial, 5) += 1; // SE & low & NC
        if(rt1(trial, mm) == 1 &&  dose1(trial, mm) == 1 && y_out1(trial, mm) == 1) num_tpnc(trial, 6) += 1; // SE & STD & TP
        if(rt1(trial, mm) == 1 &&  dose1(trial, mm) == 1 && y_out1(trial, mm) == 2) num_tpnc(trial, 7) += 1; // SE & STD & nc

        num_pat += 1;
      } //end coh1i

      time_decision(trial) += 2;

    }//end Equal randomization (before adaptive randomization)


    //////////////////////////////////////////////////////////////////
    // * 2. Allocate patients based on Adaptive randomization * //

    // time_decision(trial) += - 2; //'-2' because of 'time_decision[trial] + 2' in last cohort

    for(cohort = 0; cohort < ncohort2; cohort++){

      // Check all dose (SE: low, std / RE: std, high) are early stopped.
      // The trial continues until all dose is stopped early.
      if(ar_check_se_low(trial) + ar_check_se_std(trial) != 2 || ar_check_re_std(trial) + ar_check_re_high(trial) != 2){

        //update censored indicator based on (now) "time_decision"
        // current_delta: 1: TP, 2: NC, 0: censored
        arma::vec current_delta(num_pat, fill::zeros);
        for(i = 0; i < num_pat; i++){
          if(time_decision(trial) <= tenter2(trial, i) + tevent2(trial, i)){
            // censored (the event occur has not yet occurred)
            model_x(i) = time_decision(trial) - tenter2(trial, i);
            current_delta(i) = 0;
          }else{
            model_x(i) = tevent2(trial, i);
            current_delta(i) = y_out2(trial, i);
          }
          model_x(i) = tevent2(trial, i);
          current_delta(i) = y_out2(trial, i);
        }


        // Estimate the parameters
        output_mcmc = comp_llog_new(model_x.subvec(0, num_pat-1), model_w.subvec(0, num_pat-1),
                                       model_a.subvec(0, num_pat-1), model_b.subvec(0, num_pat-1), niter, nburn, nthin,
                                       nprint, current_delta, jump_lambda1, jump_lambda2,
                                       jump_eta1, jump_eta2, jump_gamma1, jump_gamma2,
                                       pr_mean_lambda, pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                                       pr_shape_gamma, pr_scale_gamma);

        // Save the estimated parameters
        String s(trial);
        output_mcmc_list[s] = output_mcmc;
        output_lambda1 = as<arma::mat>(output_mcmc[0]);
        output_lambda2 = as<arma::mat>(output_mcmc[1]);
        output_eta1 = as<arma::vec>(output_mcmc[2]);
        output_eta2 = as<arma::vec>(output_mcmc[3]);
        output_gamma1 = as<arma::vec>(output_mcmc[4]);
        output_gamma2 = as<arma::vec>(output_mcmc[5]);


        // * Calculate the posterior utility and dose probability (using posterior samples of parameters) * //

        double a = 0, b = 0;
        for(iter = 0; iter < real_iter; iter++){

          for(i = 0; i < 3; i++){
            lambda1(i) = output_lambda1(iter, i);
            lambda2(i) = output_lambda2(iter, i);
          }

          eta1 = output_eta1(iter);
          eta2 = output_eta2(iter);
          gamma1 = output_gamma1(iter);
          gamma2 = output_gamma2(iter);

          // For SE patients //
          // (Case 1) If all dose are not early stopped (for SE patient)
          if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 0){

            // Calculate the event occurrence probability in each interval
            util_value_se_low2.subcube(iter, 0, cohort, iter, 4, cohort) = integrate_utility_llog(1, 0, 0,
                                       eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
            util_value_se_std2.subcube(iter, 0, cohort, iter, 4, cohort) = integrate_utility_llog(1, 1, 0,
                                       eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);

            // step 1 //
            // posterior utility //
            util_value_se_low(iter, cohort, trial) = util_value_se_low2(iter, 0, cohort) * desire(0) + util_value_se_low2(iter, 1, cohort) * desire(1)+util_value_se_low2(iter, 2, cohort) * desire(2)+
              util_value_se_low2(iter, 3, cohort) * desire(3)+ util_value_se_low2(iter, 4, cohort) * desire(4);

            util_value_se_std(iter, cohort, trial) = util_value_se_std2(iter, 0, cohort) * desire(0) + util_value_se_std2(iter, 1, cohort) * desire(1)+util_value_se_std2(iter, 2, cohort) * desire(2)+
              util_value_se_std2(iter, 3, cohort) * desire(3)+util_value_se_std2(iter, 4, cohort) * desire(4);

            // step 2 //
            // Calculate the probability of TP occurrence by SE patients assigned to the (low, standard) dose //
            // Note: TP is related to the effectiveness of dose.
            model_stop_util(iter, 0, trial) = util_value_se_low2(iter, 0, cohort) + util_value_se_low2(iter, 2, cohort);
            if(model_stop_util(iter, 0, trial) > theta1) stop_se_low_tp(trial, cohort) += 1;

            model_stop_util(iter, 1, trial) = util_value_se_std2(iter, 0, cohort) + util_value_se_std2(iter, 2, cohort);
            if(model_stop_util(iter, 1, trial) > theta1) stop_se_std_tp(trial, cohort) += 1;

            // Calculate the probability of NC occurrence by SE patients assigned to the (low, standard) dose
            // Note: NC is associated with dose toxicity.
            model_stop_util(iter, 2, trial) = util_value_se_low2(iter, 1, cohort) + util_value_se_low2(iter, 3, cohort);
            if(model_stop_util(iter, 2, trial) > theta2) stop_se_low_nc(trial, cohort) += 1;

            model_stop_util(iter, 3, trial) = util_value_se_std2(iter, 1, cohort) + util_value_se_std2(iter, 3, cohort);
            if(model_stop_util(iter, 3, trial) > theta2) stop_se_std_nc(trial, cohort) += 1;


            // step 3 //
            // Calculate dose probability using posterior utility //
            if( util_value_se_low(iter, cohort, trial) < util_value_se_std(iter, cohort, trial) ) a += 1;


          }


          // (Case 2) If low dose is stopped & std dose is not early stopped (for SE patient)
          // Note: we only calculate the stop probability for std dose (because all SE patients are assigned to std dose automatically)
          if(ar_check_se_low(trial) == 1 && ar_check_se_std(trial) == 0){


            util_value_se_std2.subcube(iter, 0, cohort, iter, 4,cohort) = integrate_utility_llog(1, 1, 0,
                                       eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);

            // Calculate the probability of TP occurrence by SE patients assigned to the (standard) dose //
            model_stop_util(iter, 1, trial) = util_value_se_std2(iter, 0, cohort) + util_value_se_std2(iter, 2, cohort);
            if(model_stop_util(iter, 1, trial) > theta1) stop_se_std_tp(trial, cohort) += 1;

            // Calculate the probability of NC occurrence by SE patients assigned to the (standard) dose //
            model_stop_util(iter, 3, trial) = util_value_se_std2(iter, 1, cohort) + util_value_se_std2(iter, 3, cohort);
            if(model_stop_util(iter, 3, trial) > theta2) stop_se_std_nc(trial, cohort) += 1;

          }



          // (Case 3) If low dose is not stopped & std dose is stopped (for SE patient)
          // Note: we only calculate the stop probability for low dose (because all SE patients are assigned to low dose automatically)
          if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 1){

            util_value_se_low2.subcube(iter, 0, cohort, iter, 4,cohort) = integrate_utility_llog(1, 0, 0,
                                       eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);


            // Calculate the probability of TP occurrence by SE patients assigned to the (low) dose //
            model_stop_util(iter, 0, trial) = util_value_se_low2(iter, 0, cohort) + util_value_se_low2(iter, 2, cohort);
            if(model_stop_util(iter, 0, trial) > theta1) stop_se_low_tp(trial, cohort) += 1;

            // Calculate the probability of NC occurrence by SE patients assigned to the (low) dose //
            model_stop_util(iter, 2, trial) = util_value_se_low2(iter, 1, cohort) + util_value_se_low2(iter, 3, cohort);
            if(model_stop_util(iter, 2, trial) > theta2) stop_se_low_nc(trial, cohort) += 1;

          }


          // For RE patients //
          // (Case 1) If all dose are not early stopped (for RE patient)
          if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 0){
            util_value_re_std2.subcube(iter, 0, cohort, iter, 4,cohort) = integrate_utility_llog(0, 1, 0,
                                       eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
            util_value_re_high2.subcube(iter, 0, cohort, iter, 4,cohort) = integrate_utility_llog(0, 0, 1,
                                        eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);

            // step 1 //
            // posterior utility //
            util_value_re_high(iter, cohort, trial) = util_value_re_high2(iter, 0, cohort) * desire(0) + util_value_re_high2(iter, 1, cohort) * desire(1)+util_value_re_high2(iter, 2, cohort) * desire(2)+
              util_value_re_high2(iter, 3, cohort) * desire(3)+ util_value_re_high2(iter, 4, cohort) * desire(4);

            util_value_re_std(iter, cohort, trial) = util_value_re_std2(iter, 0, cohort) * desire(0) + util_value_re_std2(iter, 1, cohort) * desire(1)+util_value_re_std2(iter, 2, cohort) * desire(2)+
              util_value_re_std2(iter, 3, cohort) * desire(3)+ util_value_re_std2(iter, 4, cohort) * desire(4);

            // step 2 //
            // Calculate the probability of TP occurrence by RE patients assigned to the (standard, high) dose //
            // Note: TP is related to the effectiveness of dose.
            model_stop_util(iter, 4, trial) = util_value_re_high2(iter, 0, cohort) + util_value_re_high2(iter, 2, cohort);
            if(model_stop_util(iter, 4, trial) > theta1) stop_re_high_tp(trial, cohort) += 1;

            model_stop_util(iter, 5, trial) = util_value_re_std2(iter, 0, cohort) + util_value_re_std2(iter, 2, cohort);
            if(model_stop_util(iter, 5, trial) > theta1) stop_re_std_tp(trial, cohort) += 1;

            // Calculate the probability of NC occurrence by RE patients assigned to the (low, standard) dose //
            // Note: NC is related to the effectiveness of dose.
            model_stop_util(iter, 6, trial) = util_value_re_high2(iter, 1, cohort) + util_value_re_high2(iter, 3, cohort);
            if(model_stop_util(iter, 6, trial) > theta2) stop_re_high_nc(trial, cohort) += 1;

            model_stop_util(iter, 7, trial) = util_value_re_std2(iter, 1, cohort) + util_value_re_std2(iter, 3, cohort);
            if(model_stop_util(iter, 7, trial) > theta2) stop_re_std_nc(trial, cohort) += 1;

            // step 3 //
            // Calculate dose probability using posterior utility //
            if( util_value_re_high(iter, cohort, trial) < util_value_re_std(iter, cohort, trial) ) b += 1;

          }


          // (Case 2) If std dose is not stopped & high dose is early stopped (for RE patient)
          // Note: we only calculate the stop probability for std dose (because all RE patients are assigned to std dose automatically)
          if(ar_check_re_high(trial) == 1 && ar_check_re_std(trial) == 0){ //If stop re high, check re std toxicity

            util_value_re_std2.subcube(iter, 0, cohort, iter, 4, cohort) = integrate_utility_llog(0, 1, 0,
                                       eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);


            // Calculate the probability of TP occurrence by RE patients assigned to the (standard) dose //
            model_stop_util(iter, 5, trial) = util_value_re_std2(iter, 0, cohort) + util_value_re_std2(iter, 2, cohort);
            if(model_stop_util(iter, 5, trial) > theta1) stop_re_std_tp(trial, cohort) += 1;

            // Calculate the probability of NC occurrence by RE patients assigned to the (standard) dose //
            model_stop_util(iter, 7, trial) = util_value_re_std2(iter, 1, cohort) + util_value_re_std2(iter, 3, cohort);
            if(model_stop_util(iter, 7, trial) > theta2) stop_re_std_nc(trial, cohort) += 1;
          }

          // (Case 3) If std dose is stopped & high dose is not early stopped (for RE patient)
          // Note: we only calculate the stop probability for high dose (because all RE patients are assigned to high dose automatically)
          if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 1){
            // step 1 //
            util_value_re_high2.subcube(iter, 0, cohort, iter, 4,cohort) = integrate_utility_llog(0, 0, 1,
                                        eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);

            // step 2 //
            // Calculate the probability of TP occurrence by RE patients assigned to the (high) dose //
            model_stop_util(iter, 4, trial) = util_value_re_high2(iter, 0, cohort) + util_value_re_high2(iter, 2, cohort);
            if(model_stop_util(iter, 4, trial) > theta1) stop_re_high_tp(trial, cohort) += 1;

            // Calculate the probability of NC occurrence by RE patients assigned to the (high) dose //
            model_stop_util(iter, 6, trial) = util_value_re_high2(iter, 1, cohort) + util_value_re_high2(iter, 3, cohort);
            if(model_stop_util(iter, 6, trial) > theta2) stop_re_high_nc(trial, cohort) += 1;
          }


        } // End "Calculate the posterior utility and dose probability" using all posteior samples


        // * If all dose are not early stopped, Calculate dose allocation probability *//
        if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 0 ) prob_se = a / real_iter;
        if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 0 ) prob_re = b / real_iter;


        // * Check the "stop probability > q1" (if bigger than q1, stop) * //

        // For SE //
        // (Case 1) Now : all dose are not stopped.
        if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 0){
          if((stop_se_low_tp(trial, cohort)/real_iter > q1 || stop_se_low_nc(trial, cohort)/real_iter > q2) && (stop_se_std_tp(trial, cohort)/real_iter > q1 ||stop_se_std_nc(trial, cohort)/real_iter > q2)){ // both stop
            // If low dose: stop, std dose: stop
            prob_se_std(trial, cohort) = 9 ;
            prob_se = 9 ;
            ar_check_se_std(trial) = 1;
            ar_se_std_cohort(trial) = cohort;
            ar_check_se_low(trial) = 1;
            ar_se_low_cohort(trial) = cohort;
            ar_check_se_all(trial) = 1;
            ar_se_all_cohort(trial) = cohort;
          }else if((stop_se_low_tp(trial, cohort)/real_iter > q1 || stop_se_low_nc(trial, cohort)/real_iter > q2) && (stop_se_std_tp(trial, cohort)/real_iter < q1 && stop_se_std_nc(trial, cohort)/real_iter < q2)){ //low stop
            // If low dose: stop, std dose: stop x
            prob_se_std(trial, cohort) = 1;
            prob_se = 1;
            ar_check_se_low(trial) = 1;
            ar_se_low_cohort(trial) = cohort;
          }else if((stop_se_low_tp(trial, cohort)/real_iter < q1 && stop_se_low_nc(trial, cohort)/real_iter < q2) && (stop_se_std_tp(trial, cohort)/real_iter > q1 ||stop_se_std_nc(trial, cohort)/real_iter > q2)){ //std stop
            // If low dose: stop x, std dose: stop
            prob_se_std(trial, cohort) = 0;
            prob_se = 0;
            ar_check_se_std(trial) = 1;
            ar_se_std_cohort(trial) = cohort;
          }else{
            // If low dose: stop x, std dose: stop x
            prob_se_std(trial, cohort) = prob_se;
          }


        }else if(ar_check_se_low(trial) == 1 && ar_check_se_std(trial) == 0){
          // (Case 2) Now : low dose are stopped.
          // If std dose: stop
          if(stop_se_std_tp(trial, cohort)/real_iter > q1 ||stop_se_std_nc(trial, cohort)/real_iter > q2){
            prob_se_std(trial, cohort) = 9 ;
            prob_se = 9 ;
            ar_check_se_std(trial) = 1;
            ar_se_std_cohort(trial) = cohort;
            ar_check_se_all(trial) = 1;
            ar_se_all_cohort(trial) = cohort;
          }else{
            // If std dose: stop x
            prob_se_std(trial, cohort) = 1;
            prob_se = 1;
          }

        }else if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 1){
          // (Case 3) Now : std dose are stopped.
          // If low dose: stop
          if(stop_se_low_tp(trial, cohort)/real_iter > q1 || stop_se_low_nc(trial, cohort)/real_iter > q2){
            prob_se_std(trial, cohort) = 9 ;
            prob_se = 9 ;
            ar_check_se_low(trial) = 1;
            ar_se_low_cohort(trial) = cohort;
            ar_check_se_all(trial) = 1;
            ar_se_all_cohort(trial) = cohort;
          }else{
            // If low dose: stop x
            prob_se_std(trial, cohort) = 0;
            prob_se = 0;
          }
        }


        // For RE //
        // (Case 1) Now : all dose are not stopped.
        if(ar_check_re_std(trial) == 0 && ar_check_re_high(trial) == 0){
          if((stop_re_std_nc(trial, cohort)/real_iter > q2 || stop_re_std_tp(trial, cohort)/real_iter > q1) && (stop_re_high_nc(trial, cohort)/real_iter > q2 || stop_re_high_tp(trial, cohort)/real_iter > q1)){ // both stop
            // If std dose: stop, high dose: stop
            prob_re_std(trial, cohort) = 9 ;
            prob_re = 9 ;
            ar_check_re_std(trial) = 1;
            ar_re_std_cohort(trial) = cohort;
            ar_check_re_high(trial) = 1;
            ar_re_high_cohort(trial) = cohort;
            ar_check_re_all(trial) = 1;
            ar_re_all_cohort(trial) = cohort;
          }else if((stop_re_std_nc(trial, cohort)/real_iter > q2 || stop_re_std_tp(trial, cohort)/real_iter > q1) && (stop_re_high_nc(trial, cohort)/real_iter < q2 && stop_re_high_tp(trial, cohort)/real_iter < q1)){ //std stop
            // If std dose: stop, high dose: stop x
            prob_re_std(trial, cohort) = 0;
            prob_re = 0;
            ar_check_re_std(trial) = 1;
            ar_re_std_cohort(trial) = cohort;
          }else if((stop_re_std_nc(trial, cohort)/real_iter < q2 && stop_re_std_tp(trial, cohort)/real_iter < q1) && (stop_re_high_nc(trial, cohort)/real_iter > q2 || stop_re_high_tp(trial, cohort)/real_iter > q1)){ //high stop
            // If std dose: stop x, high dose: stop
            prob_re_std(trial, cohort) = 1;
            prob_re = 1;
            ar_check_re_high(trial) = 1;
            ar_re_high_cohort(trial) = cohort;
          }else{
            // If std dose: stop x, high dose: stop x
            prob_re_std(trial, cohort) = prob_re;
          }
        }else if(ar_check_re_high(trial) == 1 && ar_check_re_std(trial) == 0){
          // (Case 2) Now : high dose are stopped.
          if(stop_re_std_nc(trial, cohort)/real_iter > q2 || stop_re_std_tp(trial, cohort)/real_iter > q1){
            // If std dose: stop
            prob_re_std(trial, cohort) = 9 ;
            prob_re = 9 ;
            ar_check_re_std(trial) = 1;
            ar_re_std_cohort(trial) = cohort;
            ar_check_re_all(trial) = 1;
            ar_re_all_cohort(trial) = cohort;
          }else{
            // If std dose: stop x
            prob_re_std(trial, cohort) = 1 ;
            prob_re = 1 ;
          }
        }else if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 1){
          // (Case 3) Now : std dose are stopped.
          if(stop_re_high_nc(trial, cohort)/real_iter > q2 || stop_re_high_tp(trial, cohort)/real_iter > q1){
            // If high dose: stop
            prob_re_std(trial, cohort) = 9 ;
            prob_re = 9 ;
            ar_check_re_high(trial) = 1;
            ar_re_high_cohort(trial) = cohort;
            ar_check_re_all(trial) = 1;
            ar_re_all_cohort(trial) = cohort;
          }else{
            // If high dose: stop x
            prob_re_std(trial, cohort) = 0 ;
            prob_re = 0 ;
          }
        }


        // Allocate New patient based on probability
        // If all dose are not stopped
        if(ar_check_se_low(trial) + ar_check_se_std(trial) != 2 || ar_check_re_std(trial) + ar_check_re_high(trial) != 2){
          for(coh2i = 0; coh2i < ncohortsize; coh2i++){
            mm = ncohort1 * ncohortsize + cohort * ncohortsize + coh2i;

            // (Step 1) select RT (RE or SE)
            u = R::runif(0, 1);
            if(u < rt_prob){
              rt2(trial, mm) = 0; //RE
            }else rt2(trial, mm) = 1; //SE


            // (Step 2) select dose

            // For RE //
            if(rt2(trial, mm) == 0){
              pat_type(trial, 0) += 1;
              // Check all dose are not stopped
              if(ar_check_re_std(trial) + ar_check_re_high(trial) != 2){
                u = R::rbinom(1, prob_re);
                if(u == 1){
                  // allocate to Standard dose
                  dose2(trial, num_pat) = 1;
                  prob_tp = true_tp_re(0);
                  prob_nc = true_nc_re(0);
                  patient(trial, 0) += 1;
                  model_a(num_pat) = 1;
                  model_b(num_pat) = 0;
                }else{
                  // allocate to High dose
                  dose2(trial, num_pat) = 2;
                  prob_tp = true_tp_re(1);
                  prob_nc = true_nc_re(1);
                  patient(trial, 1) += 1;
                  model_a(num_pat) = 0;
                  model_b(num_pat) = 1;
                }

                // Generate data based on dose
                data = outcome_gen2_cpp(prob_half, prob_tp, prob_nc, rt2(trial, mm), dist, dist, 6);

                // Save data
                y_tp2(trial, num_pat) = data(1);
                y_nc2(trial, num_pat) = data(2);
                tevent2(trial, num_pat) = data(0);
                y_out2(trial, num_pat) = data(3);
                model_w(num_pat) = rt2(trial, num_pat);
                tenter2(trial, num_pat) = time_decision(trial);

                if(rt2(trial, num_pat) == 0 &&  dose2(trial, num_pat) == 1 && y_out2(trial, num_pat) == 1) num_tpnc(trial, 0) += 1; // RE(0) & STD(1) & TP(1)
                if(rt2(trial, num_pat) == 0 &&  dose2(trial, num_pat) == 1 && y_out2(trial, num_pat) == 2) num_tpnc(trial, 1) += 1; // RE & STD & NC
                if(rt2(trial, num_pat) == 0 &&  dose2(trial, num_pat) == 2 && y_out2(trial, num_pat) == 1) num_tpnc(trial, 2) += 1; // RE & high & TP
                if(rt2(trial, num_pat) == 0 &&  dose2(trial, num_pat) == 2 && y_out2(trial, num_pat) == 2) num_tpnc(trial, 3) += 1; // RE & high & NC

                num_pat += 1;
              }
            }else if(rt2(trial, mm) == 1){
              // For SE //
              pat_type(trial, 1) += 1;
              if(ar_check_se_low(trial) + ar_check_se_std(trial) != 2){
                // Check all dose are not stopped
                u = R::rbinom(1, prob_se);
                if(u == 0){
                  // allocate to Low dose
                  dose2(trial, num_pat) = 0;
                  prob_tp = true_tp_se(0);
                  prob_nc = true_nc_se(0);
                  patient(trial, 2) += 1;
                  model_a(num_pat) = 0;
                  model_b(num_pat) = 0;
                }else{
                  // allocate to Standard dose
                  dose2(trial, num_pat) = 1;
                  prob_tp = true_tp_se(1);
                  prob_nc = true_nc_se(1);
                  patient(trial, 3) += 1;
                  model_a(num_pat) = 1;
                  model_b(num_pat) = 0;
                }

                // Generate data based on dose
                data = outcome_gen2_cpp(prob_half, prob_tp, prob_nc, rt2(trial, mm), dist, dist, 6);

                // Save data
                y_tp2(trial, num_pat) = data(1);
                y_nc2(trial, num_pat) = data(2);
                tevent2(trial, num_pat) = data(0);
                y_out2(trial, num_pat) = data(3);
                model_w(num_pat) = rt2(trial, num_pat);
                tenter2(trial, num_pat) = time_decision(trial);

                if(rt2(trial, num_pat) == 1 &&  dose2(trial, num_pat) == 0 && y_out2(trial, num_pat) == 1) num_tpnc(trial, 4) += 1; // SE & low & TP(1)
                if(rt2(trial, num_pat) == 1 &&  dose2(trial, num_pat) == 0 && y_out2(trial, num_pat) == 2) num_tpnc(trial, 5) += 1; // SE & low & NC
                if(rt2(trial, num_pat) == 1 &&  dose2(trial, num_pat) == 1 && y_out2(trial, num_pat) == 1) num_tpnc(trial, 6) += 1; // SE & STD & TP
                if(rt2(trial, num_pat) == 1 &&  dose2(trial, num_pat) == 1 && y_out2(trial, num_pat) == 2) num_tpnc(trial, 7) += 1; // SE & STD & nc

                num_pat += 1;
              }
            }
          } // end for coh2i
          time_decision(trial) +=  2;
        } // Allocate the all new patients

        // // Print
        // Rcpp::Rcout << "trial: " << trial+1 << "/ cohort: " << cohort+1 << std::endl;
        // Rcpp::Rcout << "early_se: " << ar_check_se_low(trial) << "/" << ar_check_se_std(trial) << std::endl;
        // Rcpp::Rcout << "early_re: " << ar_check_re_std(trial) << "/" << ar_check_re_high(trial) << std::endl;
        // Rcpp::Rcout << "prob_se_standard: " << prob_se << "/ prob_re_standard: " << prob_re << std::endl;
      }
    } // End adaptive randomization (cohort 2)



    ////////////////////////////////////////////////

    // * 3. Select final dose * //

    if(ar_check_se_low(trial) + ar_check_se_std(trial) != 2 || ar_check_re_std(trial) + ar_check_re_high(trial) != 2){
      ///update censored indicator based on (now) "time_decision"
      arma::vec current_delta(num_pat, fill::zeros);
      for(i = 0; i < num_pat; i++){
        if(time_decision(trial) - tenter2(trial, i) <= tevent2(trial, i)){
          //censored
          model_x(i) = time_decision(trial) - tenter2(trial, i);
          current_delta(i) = 0;
        }else{
          model_x(i) = tevent2(trial, i);
          current_delta(i) = y_out2(trial, i);
        }
        model_x(i) = tevent2(trial, i);
        current_delta(i) = y_out2(trial, i);
      }

      // Estimate the parameters
      output_mcmc = comp_llog_new(model_x.subvec(0, num_pat-1), model_w.subvec(0, num_pat-1),
                                     model_a.subvec(0, num_pat-1), model_b.subvec(0, num_pat-1), niter, nburn, nthin,
                                     nprint, current_delta, jump_lambda1, jump_lambda2,
                                     jump_eta1, jump_eta2, jump_gamma1, jump_gamma2,
                                     pr_mean_lambda, pr_sd_lambda, pr_shape_eta, pr_scale_eta,
                                     pr_shape_gamma, pr_scale_gamma);

      // Save the estimated parameters
      String s(trial);
      output_mcmc_list[s] = output_mcmc;
      output_lambda1 = as<arma::mat>(output_mcmc[0]);
      output_lambda2 = as<arma::mat>(output_mcmc[1]);
      output_eta1 = as<arma::vec>(output_mcmc[2]);
      output_eta2 = as<arma::vec>(output_mcmc[3]);
      output_gamma1 = as<arma::vec>(output_mcmc[4]);
      output_gamma2 = as<arma::vec>(output_mcmc[5]);

      // * Calculate the posterior utility and dose probability (using posterior samples of parameters) * //
      double a = 0, b = 0;
      for(iter = 0; iter < real_iter; iter++){
        for(i = 0; i < 3; i++){
          lambda1(i) = output_lambda1(iter, i);
          lambda2(i) = output_lambda2(iter, i);
        }

        eta1 = output_eta1(iter);
        eta2 = output_eta2(iter);
        gamma1 = output_gamma1(iter);
        gamma2 = output_gamma2(iter);

        // For SE patients //
        // (Case 1) If all dose are not early stopped (for SE patient)
        if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 0){


          util_value_se_low2.subcube(iter, 0, ncohort2, iter, 4, ncohort2) = integrate_utility_llog(1, 0, 0,
                                     eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
          util_value_se_std2.subcube(iter, 0, ncohort2, iter, 4, ncohort2) = integrate_utility_llog(1, 1, 0,
                                     eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);

          // step 1 //
          // Calculate the posterior Utility for each (low, standard) dose //
          // Note: TP is related to the effectiveness of dose.
          util_value_se_low(iter, ncohort2, trial) = util_value_se_low2(iter, 0, ncohort2) * desire(0) + util_value_se_low2(iter, 1, ncohort2) * desire(1)+util_value_se_low2(iter, 2, ncohort2) * desire(2)+
            util_value_se_low2(iter, 3, ncohort2) * desire(3)+ util_value_se_low2(iter, 4, ncohort2) * desire(4);
          util_value_se_std(iter, ncohort2, trial) = util_value_se_std2(iter, 0, ncohort2) * desire(0) + util_value_se_std2(iter, 1, ncohort2) * desire(1)+util_value_se_std2(iter, 2, ncohort2) * desire(2)+
            util_value_se_std2(iter, 3, ncohort2) * desire(3)+util_value_se_std2(iter, 4, ncohort2) * desire(4);

          // step 3 //
          // Calculate dose probability using posterior utility //
          if( util_value_se_low(iter, ncohort2, trial) < util_value_se_std(iter, ncohort2, trial) ) a += 1;

        }

        if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 0){

          util_value_re_std2.subcube(iter, 0, ncohort2, iter, 4,ncohort2) = integrate_utility_llog(0, 1, 0,
                                     eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);
          util_value_re_high2.subcube(iter, 0, ncohort2, iter, 4,ncohort2) = integrate_utility_llog(0, 0, 1,
                                      eta1, eta2, gamma1, gamma2, lambda1, lambda2, total_eval_time, INFINITY);

          util_value_re_high(iter, ncohort2, trial) = util_value_re_high2(iter, 0, ncohort2) * desire(0) + util_value_re_high2(iter, 1, ncohort2) * desire(1)+util_value_re_high2(iter, 2, ncohort2) * desire(2)+
            util_value_re_high2(iter, 3, ncohort2) * desire(3)+ util_value_re_high2(iter, 4, ncohort2) * desire(4);

          util_value_re_std(iter, ncohort2, trial) = util_value_re_std2(iter, 0, ncohort2) * desire(0) + util_value_re_std2(iter, 1, ncohort2) * desire(1)+util_value_re_std2(iter, 2, ncohort2) * desire(2)+
            util_value_re_std2(iter, 3, ncohort2) * desire(3)+ util_value_re_std2(iter, 4, ncohort2) * desire(4);

          //Calculate dose probablity
          if( util_value_re_high(iter, ncohort2, trial) < util_value_re_std(iter, ncohort2, trial) ) b += 1;
        }


      }

      if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 0 ) prob_se = a / real_iter;
      if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 0 ) prob_re = b / real_iter;


    }

    if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 0){
      final_se_std(trial) =  R::rbinom(1, prob_se); // Std:1, Low:0 /
    }else if(ar_check_se_low(trial) == 1 && ar_check_se_std(trial) == 0){
      final_se_std(trial) = 1;
      early_se1 += 1; // early stop for low dose efficacy
    }else if(ar_check_se_low(trial) == 0 && ar_check_se_std(trial) == 1){
      final_se_std(trial) = 0;
      early_se2 += 1; // early stop for std dose efficacy
    }else{
      final_se_std(trial) = 9;
      early_se1 += 1;
      early_se2 += 1;
      se_all_stop +=1;
      // early stop for se
    }

    if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 0){
      final_re_std(trial) = 2 - R::rbinom(1, prob_re); // High:2, Std: 1
    }else if(ar_check_re_high(trial) == 1 && ar_check_re_std(trial) == 0){
      final_re_std(trial) = 1;
      early_re1 += 1; //
    }else if(ar_check_re_high(trial) == 0 && ar_check_re_std(trial) == 1){
      final_re_std(trial) = 2;
      early_re2 += 1; // e
    }else{
      final_re_std(trial) = 9;
      early_re1 += 1;
      early_re2 += 1;
      re_all_stop +=1;// early stop for re
    }

    cured_pat(trial) = num_pat;

    String s(trial);
    util_value_se_low2_list[s] = util_value_se_low2;
    util_value_se_std2_list[s] = util_value_se_std2;
    util_value_re_std2_list[s] = util_value_re_std2;
    util_value_re_high2_list[s] = util_value_re_high2;

  } // trial end
  Rcpp::List output;
  output["rt"] = rt2;
  output["rt&dose"] = patient;
  output["dose"] = dose2;
  output["event_time"] = tevent2;
  output["outcome"] = y_out2;
  output["num_tpnc"] = num_tpnc;
  output["output_mcmc_list"] = output_mcmc_list;
  output["early_stop_se_low_indicator"] = ar_check_se_low;
  output["early_stop_se_std_indicator"] = ar_check_se_std;
  output["early_stop_re_high_indicator"] = ar_check_re_high;
  output["early_stop_re_std_indicator"] = ar_check_re_std;
  output["early_stop_re_all_indicator"] = ar_check_re_all;
  output["early_stop_se_all_indicator"] = ar_check_se_all;

  output["early_stop_se_all_cohort"] = ar_se_all_cohort;
  output["early_stop_re_all_cohort"] = ar_re_all_cohort;
  output["early_stop_se_low_cohort"] = ar_se_low_cohort;
  output["early_stop_se_std_cohort"] = ar_se_std_cohort;
  output["early_stop_re_std_cohort"] = ar_re_std_cohort;
  output["early_stop_re_high_cohort"] = ar_re_high_cohort;

  output["util_value_se_low"] = util_value_se_low;
  output["util_value_se_std"] = util_value_se_std;
  output["util_value_re_std"] = util_value_re_std;
  output["util_value_re_high"] = util_value_re_high;
  output["util_value_se_low_temp"] = util_value_se_low2_list;
  output["util_value_se_std_temp"] = util_value_se_std2_list;
  output["util_value_re_std_temp"] = util_value_re_std2_list;
  output["util_value_re_high_temp"] = util_value_re_high2_list;
  output["cumulative_inc_prob"] = model_stop_util;

  output["cured_patient"] = cured_pat;
  output["prob_re_std"] = prob_re_std;
  output["prob_se_std"] = prob_se_std;
  output["final_re_std"] = final_re_std;
  output["final_se_std"] = final_se_std;
  output["early_stop_se_low"] = early_se1;
  output["early_stop_se_std"] = early_se2;
  output["early_stop_re_high"] = early_re1;
  output["early_stop_re_std"] = early_re2;
  output["early_stop_re_all"] = re_all_stop;
  output["early_stop_se_all"] = se_all_stop;
  return(output);
}


